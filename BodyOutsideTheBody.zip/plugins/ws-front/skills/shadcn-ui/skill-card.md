## Description: <br>
Use when building UI with shadcn/ui components, Tailwind CSS layouts, form patterns with react-hook-form and zod, theming, dark mode, sidebar layouts, mobile navigation, or any shadcn component question. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[jgarrison929](https://clawhub.ai/user/jgarrison929) <br>

### License/Terms of Use: <br>


## Use Case: <br>
Developers and engineers use this skill to get implementation guidance for shadcn/ui, Tailwind CSS layouts, react-hook-form and zod form patterns, theming, dark mode, sidebar layouts, and mobile navigation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Suggested npx and npm commands may add packages or generate project files. <br>
Mitigation: Run commands only inside the intended project and review generated file changes before committing or deploying. <br>
Risk: Broad UI-related triggers may activate this skill for generic frontend requests. <br>
Mitigation: Confirm shadcn/ui, Tailwind CSS, form, theming, sidebar, or related component guidance is actually needed before applying its recommendations. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/jgarrison929/shadcn-ui) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with TypeScript, CSS, and bash code blocks] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Documentation-only guidance; command examples should be reviewed before execution in a project.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
