#!/usr/bin/env bash
#
# Maven 仓库工具 - Bash 脚本
# 功能:
#   1. 查看本地 Maven 仓库中 JAR 依赖的 Java 源代码 (需 -sources.jar)
#   2. 查看依赖对应的 POM 文件内容
#
# 用法:
#   # 查看源码
#   ./mvn_tools.sh source -d org.springframework:spring-core:6.0.0 -c org.springframework.core.io.Resource
#
#   # 查看 POM
#   ./mvn_tools.sh pom -d org.springframework:spring-core:6.0.0
#
#   # 指定自定义仓库路径
#   ./mvn_tools.sh pom -r /custom/repo -d com.example:my-lib:1.0.0

set -euo pipefail

# ── 解析坐标 groupId:artifactId:version ──
parse_coordinates() {
    local coord="$1"
    IFS=':' read -r GROUP_ID ARTIFACT_ID VERSION <<< "$coord"

    if [[ -z "${GROUP_ID:-}" ]] || [[ -z "${ARTIFACT_ID:-}" ]]; then
        echo "错误: 无效的坐标格式，应为 groupId:artifactId:version" >&2
        exit 1
    fi
}

# ── 定位文件路径 ──
resolve_dir() {
    local repo="$1" group_id="$2" artifact_id="$3" version="$4"
    echo "${repo}/${group_id//.//}/${artifact_id}/${version}"
}

# ── 命令: source ──
cmd_source() {
    if [[ -z "${VERSION:-}" ]]; then
        echo "错误: 查看源码时必须指定版本，格式: groupId:artifactId:version" >&2
        exit 1
    fi

    local dir
    dir=$(resolve_dir "$REPO" "$GROUP_ID" "$ARTIFACT_ID" "$VERSION")
    local sources_jar="${dir}/${ARTIFACT_ID}-${VERSION}-sources.jar"

    if [[ ! -f "$sources_jar" ]]; then
        echo "错误: 找不到 sources jar: ${sources_jar}" >&2
        if [[ -d "$dir" ]]; then
            echo "该目录下的 jar 文件:" >&2
            ls "$dir"/*.jar 2>/dev/null | while read -r f; do echo "  - $(basename "$f")" >&2; done
        fi
        exit 1
    fi

    local class_path="${CLASS_NAME//.//}.java"

    # 列出 jar 中所有文件，精确匹配路径
    local match
    match=$(unzip -l "$sources_jar" 2>/dev/null | awk -v p="$class_path" 'NF>=4 && $4 == p {print $4; exit}' || true)

    # 如果精确查找失败，尝试模糊匹配（按类名后缀匹配路径结尾）
    if [[ -z "$match" ]]; then
        local short_name="${CLASS_NAME##*.}.java"
        match=$(unzip -l "$sources_jar" 2>/dev/null | awk -v s="$short_name" 'NF>=4 && $4 ~ s"$" {print $4; exit}' || true)
    fi

    if [[ -z "$match" ]]; then
        echo "错误: 在 ${sources_jar} 中找不到类 ${CLASS_NAME}" >&2
        exit 1
    fi

    # 使用 unzip -p 直接输出到 stdout，不解压到磁盘
    unzip -p "$sources_jar" "$match"
}

# ── 命令: pom ──
cmd_pom() {
    if [[ -z "${VERSION:-}" ]]; then
        echo "错误: 查看 POM 时必须指定版本，格式: groupId:artifactId:version" >&2
        exit 1
    fi

    local dir
    dir=$(resolve_dir "$REPO" "$GROUP_ID" "$ARTIFACT_ID" "$VERSION")
    local pom_file="${dir}/${ARTIFACT_ID}-${VERSION}.pom"

    if [[ ! -f "$pom_file" ]]; then
        echo "错误: 找不到 POM 文件: ${pom_file}" >&2
        exit 1
    fi

    cat "$pom_file"
}

# ── CLI 参数解析 ──
COMMAND=""
REPO=""
DEP=""
CLASS_NAME=""
GROUP_ID=""
ARTIFACT_ID=""
VERSION=""

usage() {
    cat <<EOF
用法:
  $0 source -r REPO -d GROUP:ARTIFACT:VERSION -c CLASS_NAME
  $0 pom    -r REPO -d GROUP:ARTIFACT:VERSION

选项:
  -r  指定 Maven 本地仓库路径（必填）
  -d  Maven 坐标 groupId:artifactId:version
  -c  类全限定名（仅 source 命令需要）
  -h  显示帮助
EOF
}

if [[ $# -eq 0 ]]; then
    usage
    exit 1
fi

# 支持 -h 作为第一个参数
if [[ "$1" == "-h" ]]; then
    usage
    exit 0
fi

# 第一个参数必须是子命令
COMMAND="$1"
shift

while [[ $# -gt 0 ]]; do
    case "$1" in
        -r) REPO="$2"; shift 2 ;;
        -d) DEP="$2"; shift 2 ;;
        -c) CLASS_NAME="$2"; shift 2 ;;
        -h) usage; exit 0 ;;
        *)  echo "未知参数: $1" >&2; usage; exit 1 ;;
    esac
done

# 解析坐标
if [[ -n "$DEP" ]]; then
    parse_coordinates "$DEP"
fi

# 校验必填参数
if [[ -z "$REPO" ]]; then
    echo "错误: 必须使用 -r 指定 Maven 本地仓库路径" >&2
    usage
    exit 1
fi

# 执行命令
case "$COMMAND" in
    source|sc) cmd_source ;;
    pom|p)     cmd_pom ;;
    *)         echo "未知命令: ${COMMAND}" >&2; usage; exit 1 ;;
esac
