---
name: ws-maven-reader
description: >
  Read POM files and Java source code from local Maven dependencies. Use this skill when you
  are solving a user's problem and realize you need to look inside a Maven dependency to
  proceed — such as when debugging an error caused by a third-party library, understanding
  how a framework class actually works (e.g. annotations, base classes, utility methods),
  verifying dependency configuration or transitive dependencies via pom.xml, or comparing
  versions across artifacts. Trigger proactively: whenever understanding a dependency's
  internal behavior would help you give a more accurate answer, even if the user never
  mentioned Maven, JARs, or dependencies explicitly.

  当 AI 在解答用户问题、编写代码、排查报错时，如果发现需要深入理解某个 Maven 依赖的
  内部实现才能给出准确答案，就应主动触发此 skill。典型场景：排查第三方库引起的报错、
  理解框架注解或工具类的源码实现、通过 pom.xml 确认依赖配置和传递依赖、对比不同版本
  的 API 差异等。即使用户没有提到 Maven、jar 包或依赖，只要理解依赖源码有助于回答问题，
  就应触发。
compatibility: bash environment (Linux, macOS, or Windows with Git Bash)
user-invocable: false
model-invocable: true
version: 1.0.0
---

## Maven Reader

This skill lets you read POM files and Java source code from Maven dependencies in the local
repository, using the `mvn_tools.sh` script.

## Locating the Maven Local Repository

Before running any command, you need the path to the user's Maven local repository. Try these
approaches in order until you find it:

1. **Check IDEA workspace configuration** — if the project has a `.idea` directory, read
   `.idea/workspace.xml` to find the Maven home path and local repository configuration.
   This is the most reliable method for IDEA projects.

2. **Run `mvn` to get the local repository path** — if `mvn` is available, run:
   ```bash
   mvn help:evaluate -Dexpression=settings.localRepository -q -DforceStdout
   ```
   If `mvn` is not in PATH, locate it from common paths:
   - Linux: `/usr/bin/mvn`, `/usr/local/bin/mvn`
   - macOS: `/usr/local/bin/mvn`, or via Homebrew at `/opt/homebrew/bin/mvn`
   - Windows: check system environment variables, or locate bundled Maven in IntelliJ IDEA

3. **Check project configuration** — look for `<localRepository>` in:
   - Project `pom.xml`
   - `.mvn/maven.config`

4. **Check Maven settings files** — look for `<localRepository>` in:
   - User settings: `~/.m2/settings.xml` (or `%USERPROFILE%\.m2\settings.xml` on Windows)
   - Global settings: `${MAVEN_HOME}/conf/settings.xml`
   If no `<localRepository>` is specified, the default is `~/.m2/repository`.

5. **Check environment variables** — look for `MAVEN_REPO_LOCAL` or `M2_HOME`.

6. **Use the default** — `~/.m2/repository` (Linux/macOS) or
   `%USERPROFILE%\.m2\repository` (Windows).

Once you find it, remember the path for the rest of the session.

## The mvn_tools.sh Utility

The `mvn_tools.sh` script is bundled in the `scripts/` directory alongside this SKILL.md.
Execute it via bash:

```bash
bash <skill-directory>/scripts/mvn_tools.sh <command> [options]
```

**Supported commands:**

| Command | Alias | Function |
|---------|-------|----------|
| `pom` | `p` | View dependency POM file content |
| `source` | `sc` | View Java source code from a dependency (requires `-sources.jar`) |

## Viewing a Dependency's POM File

To read the `pom.xml` of a Maven dependency:

```bash
bash <path-to-mvn_tools.sh> pom -r <repo-path> -d <groupId:artifactId:version>
```

Parameters:
- `-r` — path to the local Maven repository directory
- `-d` — dependency coordinate in `groupId:artifactId:version` format

Example:
```bash
bash plugins/ws-java-common/skills/ws-maven-reader/scripts/mvn_tools.sh pom \
  -r ~/.m2/repository \
  -d org.springframework.boot:spring-boot-test:4.0.2
```

## Viewing a Java Class's Source Code

To read the source code of a specific Java class from a Maven dependency:

```bash
bash <path-to-mvn_tools.sh> source -r <repo-path> -d <groupId:artifactId:version> -c <fully.qualified.ClassName>
```

Parameters:
- `-r` — path to the local Maven repository directory
- `-d` — dependency coordinate in `groupId:artifactId:version` format
- `-c` — fully qualified class name

Example:
```bash
bash plugins/ws-java-common/skills/ws-maven-reader/scripts/mvn_tools.sh source \
  -r ~/.m2/repository \
  -d org.springframework.boot:spring-boot-test:4.0.2 \
  -c org.springframework.boot.test.context.SpringBootTest
```

## Tips

- The tool outputs content directly to stdout. You can then analyze, explain, or act on it as
  needed.
- `source` command requires the dependency to have a `-sources.jar` in the local repository,
  otherwise it will fail with an error.
- If you don't know a dependency's version, check the project's `pom.xml` or `build.gradle`
  to find it first.
- For exploring multiple classes from the same dependency, reuse the same `-r` and `-d`
  parameters and only change `-c`.
