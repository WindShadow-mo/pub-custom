---
name: ws-java-3rd
description: 编写第三方服务对接模块时使用此skill。触发场景：项目设计了第三方模块，且需要编写调用外部api的代码时触发，如对接微信、支付宝等外部接口
user-invocable: false
model-invocable: true
version: 1.0.0
---

# 第三方服务对接模块开发规范

## 模块定位

第三方服务对接模块集中管理所有外部 HTTP API 的声明、DTO、自动装配和配置。

**设计原则：**

- 不依赖 starter，仅引入直接包依赖，保持轻量
- 使用 Spring `@HttpExchange` 声明式 HTTP 调用，替代手动 `RestTemplate`/`WebClient`
- 通过自动装配提供即用型 API 代理，调用方直接注入使用

## 模块依赖

### 核心依赖

| 依赖 | 用途 | Scope |
|------|------|-------|
| `spring-web` | `@HttpExchange`、`RestClient` 核心 API | compile |
| `jackson-databind` | JSON 序列化/反序列化 | compile |
| `spring-boot-autoconfigure` | `@AutoConfiguration`、`@ConfigurationProperties` | compile |
| `spring-boot-starter-validation` | 配置校验注解（`@NotBlank`、`@NotNull`） | compile |
| `spring-boot` | `@ConfigurationProperties` 编译需要 | provided |
| `lombok` | 配置类 `@Data` 简化 | optional |
| `spring-boot-configuration-processor` | IDE 配置元数据生成 | optional |

### 依赖原则

- **compile scope 仅引直接包**，不引 starter（业务模块无启动类，不需要自动配置）
- **provided scope** 用于 `@ConfigurationProperties` 等编译需要但运行时由 app 模块提供的类
- **optional=true** 用于 lombok、configuration-processor 等非运行时必需的依赖

## 目录结构

```
third-party/src/main/java/{root}/third/
├── autoconfiguration/
│   ├── ThirdPartyAutoConfiguration.java   # 自动装配入口
│   └── properties/
│       └── XxxApiProperties.java          # 配置属性类
├── {service}/                              # 按服务名分包（如 wechat、alipay）
│   ├── XxxApi.java                         # @HttpExchange 接口
│   └── pojo/
│       ├── XxxRequest.java                 # 请求 DTO（如有）
│       └── XxxResponse.java               # 响应 DTO
```

> `{root}` 替换为项目根包名，`{service}` 替换为具体服务名。

## 开发规范

### 1. @HttpExchange 接口

- **接口位置**：`{root}.third.{service}` 包下
- **DTO 位置**：`{root}.third.{service}.pojo` 包下
- 接口标注 `@HttpExchange`（类级），方法标注 `@GetExchange`/`@PostExchange`
- 使用 `@RequestParam` 显式指定 HTTP 参数名，尤其当与 Java 变量名不一致时
- 返回类型使用 **Java record**，不可变且语义清晰

```java
@HttpExchange
public interface XxxApi {

    @GetExchange("/api/v1/some-endpoint")
    XxxResponse someOperation(
            @RequestParam("param1") String param1,
            @RequestParam("param_2") String param2);
}
```

### 2. 响应 DTO（record）

- 使用 record 定义，不可变、简洁
- 使用 `@JsonProperty` 映射下划线 JSON 字段到驼峰 Java 变量
- 每个响应 record 提供 `isSuccess()` 方法，统一判断逻辑（errcode 为 null 或 0 视为成功）

```java
public record XxxResponse(
        @JsonProperty("result_data") String resultData,
        Integer errcode,
        String errmsg) {

    public boolean isSuccess() {
        return errcode == null || errcode == 0;
    }
}
```

### 3. 配置属性类

- 放在 `{root}.third.autoconfiguration.properties` 包下
- 使用 `@ConfigurationProperties` 前缀，**按配置性质选择前缀**：
    - **应用基础设施配置**（与业务无关的第三方服务凭证、地址）：以 `app.third.{service}` 开头，如 `app.third.wechat`
    - **业务相关配置**（与产品业务强相关的参数）：以产品名（项目名）开头，如 `fc.xxx.yyy`
- 使用 `@Validated` + `@NotBlank`/`@NotNull` 校验必填项
- 使用 `@Data`（Lombok）简化 getter/setter
- **远程服务地址统一用 `host` 字段名**，提供合理的默认值

```java
@Data
@Validated
@ConfigurationProperties(prefix = "third.xservice")
public class XserviceApiProperties {

    @NotBlank
    private String host = "https://api.example.com";

    @NotBlank
    private String apiKey;

    @NotBlank
    private String apiSecret;
}
```

### 4. 自动装配类

- 放在 `{root}.third.autoconfiguration` 包下
- 使用 `@AutoConfiguration` + `@ConditionalOnClass(RestClient.class)` 控制加载
- 使用 `@EnableConfigurationProperties` 注册配置类
- 通过方法参数注入全局 `RestClient.Builder`（Spring Boot `RestClientAutoConfiguration` 自动提供）
- **必须 `.clone()` 后再配置 `baseUrl()`**，避免修改污染全局 Builder
- 导入使用 `RestClientAdapter`（`org.springframework.web.client.support`）

```java
@AutoConfiguration
@ConditionalOnClass(RestClient.class)
@EnableConfigurationProperties(XserviceApiProperties.class)
public class ThirdPartyAutoConfiguration {

    @Bean
    public XxxApi xxxApi(RestClient.Builder builder, XserviceApiProperties properties) {
        RestClient restClient = builder.clone().baseUrl(properties.getHost()).build();
        HttpServiceProxyFactory factory = HttpServiceProxyFactory
                .builderFor(RestClientAdapter.create(restClient))
                .build();
        return factory.createClient(XxxApi.class);
    }
}
```

### 5. 自动装配注册

在 `src/main/resources/META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports` 中注册自动装配类全限定名。

## 调用方使用方式

业务模块添加对本模块的依赖后，构造函数注入即可：

```java
@Service
public class XxxAuthService {

    private final XxxApi xxxApi;
    private final XserviceApiProperties properties;

    public XxxAuthService(XxxApi xxxApi, XserviceApiProperties properties) {
        this.xxxApi = xxxApi;
        this.properties = properties;
    }

    public void doSomething() {
        XxxResponse response = xxxApi.someOperation(
                properties.getApiKey(), properties.getApiSecret());
        if (!response.isSuccess()) {
            throw new BusinessException("第三方服务调用失败: " + response.errmsg());
        }
    }
}
```

## 配置示例

```yaml
third:
  xservice:
    host: https://api.example.com     # 可选，默认值为文档中指定的 URL
    api-key: ${XSERVICE_API_KEY}      # 必填，@NotBlank
    api-secret: ${XSERVICE_API_SECRET} # 必填，@NotBlank
```

## 新增第三方服务模板

接入新第三方服务时，按以下步骤操作：

1. 在 `{root}.third.{service}` 下创建 `@HttpExchange` 接口
2. 在 `{root}.third.{service}.pojo` 下创建响应 record（含 `isSuccess()`）
3. 在 `{root}.third.autoconfiguration.properties` 下创建配置属性类（`@Data` + `@Validated` + `@NotBlank`）
4. 在自动装配类中新增 `@Bean` 方法（`.clone()` + `baseUrl(properties.getHost())`）
5. 在 `AutoConfiguration.imports` 中注册（若尚未注册）
