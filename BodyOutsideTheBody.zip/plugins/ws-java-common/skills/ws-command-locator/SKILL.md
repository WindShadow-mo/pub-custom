---
name: ws-command-locator
description: 当需要在项目中执行终端命令（支持Java、Maven、Node.js、npm、Python）时使用此 skill。它帮助找到适合当前项目的正确程序版本，避免使用系统默认版本导致兼容性问题。触发场景：运行任何终端命令前，即使项目没有明确的版本配置，也应使用此 skill 确认合适的程序路径。
user-invocable: false
model-invocable: true
version: 1.0.0
---

# 命令定位器 (Command Locator)

本技能帮助你在执行终端命令时找到适合当前项目的正确程序版本。

## 核心原则

1. **不要使用系统默认的 PATH 命令** - 系统中可能安装了多个版本的程序（如 Java 8/11/21、Maven 3.x、Node 16/18/20 等）
2. **IDEA 项目优先读取 workspace.xml** - 如果项目根目录存在 `.idea` 目录，优先从 `.idea/workspace.xml` 和 `.idea/misc.xml` 中获取程序路径和版本配置
3. **传递 IDEA 配置的环境变量和参数** - IDEA 项目中配置的运行参数（如 Maven 的 `-D` 参数、环境变量等）必须传递给命令
4. **使用绝对路径执行命令** - 找到正确的程序后，使用完整路径执行，避免环境变量干扰
5. **从 CLAUDE.md 读取已保存的程序路径** - 项目根目录的 `CLAUDE.md` 可能包含已配置的程序路径，优先读取
6. **找不到程序时询问用户并提供保存选项** - 如果找不到合适的程序版本，询问用户并建议将路径保存到 `CLAUDE.md` 以便后续使用

## 支持的程序类型

### Java

#### IDEA 项目配置（最高优先级）

如果项目存在 `.idea/misc.xml` 或 `.idea/workspace.xml`：

**misc.xml** - 读取 `<component name="ProjectRootManager">`：
```xml
<component name="ProjectRootManager" version="2" languageLevel="JDK_21" default="true" project-jdk-name="21" project-jdk-type="JavaSDK">
```
- `languageLevel="JDK_21"` - 指定 Java 版本为 21
- `project-jdk-name="21"` - JDK 名称

**workspace.xml** - 可能包含更详细的 JDK 路径配置。

#### 常见安装位置（IDEA 项目外使用）

- Windows: `C:\Program Files\Java\jdk*`, `C:\Program Files\Eclipse Adoptium\jdk*`
- Windows (自定义): `D:\program\jdk8`, `D:\program\jdk11`, `D:\program\jdk21`
- macOS: `/Library/Java/JavaVirtualMachines/jdk*.jdk/Contents/Home`
- Linux: `/usr/lib/jvm/java-*-openjdk-*`

#### 版本判断方法

1. **IDEA 项目** - 优先读取 `.idea/misc.xml` 和 `.idea/workspace.xml`
2. 检查 `pom.xml` 或 `build.gradle` 中的 Java 版本配置
3. 检查是否有 `.tool-versions` 文件（asdf 版本管理器）
4. 默认选择最新 LTS 版本（通常是 17 或 21）

#### 执行命令示例

```bash
# 错误：直接使用可能调用系统默认版本
java -version

# 正确：使用绝对路径
"C:\Program Files\Java\jdk-21\bin\java.exe" -version
```

### Maven

#### IDEA 项目配置（最高优先级）

如果项目存在 `.idea/workspace.xml`，读取以下组件：

**1. MavenImportPreferences** - Maven 安装配置：

```xml
<component name="MavenImportPreferences">
  <option name="generalSettings">
    <MavenGeneralSettings>
      <option name="customMavenHome" value="D:\program\Maven\apache-maven-3.9.12" />
      <option name="mavenHomeTypeForPersistence" value="CUSTOM" />
      <option name="useMavenConfig" value="false" />
      <option name="userSettingsFile" value="D:\program\Maven\settings.xml" />
    </MavenGeneralSettings>
  </option>
</component>
```

- `customMavenHome` - Maven 安装目录
- `userSettingsFile` - Maven settings.xml 配置文件路径

**2. MavenRunner** - 运行环境变量和参数：

```xml
<component name="MavenRunner">
  <option name="environmentProperties">
    <map>
      <entry key="GRAALVM_HOME" value="D:\program\graalvm-jdk-25" />
      <entry key="JAVA_TOOL_OPTIONS" value="-Dfile.encoding=UTF-8" />
      <entry key="MAVEN_OPTS" value="-Dsun.stdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 -Dconsole.encoding=UTF-8 -Dfile.encoding=UTF-8" />
    </map>
  </option>
  <option name="skipTests" value="true" />
</component>
```

- `environmentProperties` - 环境变量配置，执行命令时需要设置
- `JAVA_TOOL_OPTIONS` - Java 工具选项，会自动传递给 JVM
- `MAVEN_OPTS` - Maven 运行时选项

**执行命令示例（使用 IDEA 配置的 Maven 和环境变量）**：

```bash
# Windows PowerShell - 设置环境变量后执行
$env:GRAALVM_HOME="D:\program\graalvm-jdk-25"
$env:JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF-8"
$env:MAVEN_OPTS="-Dsun.stdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 -Dconsole.encoding=UTF-8 -Dfile.encoding=UTF-8"
"D:\program\Maven\apache-maven-3.9.12\bin\mvn.cmd" clean install -s "D:\program\Maven\settings.xml"

# 或在一行中执行
$env:GRAALVM_HOME="D:\program\graalvm-jdk-25"; $env:JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF-8"; $env:MAVEN_OPTS="-Dsun.stdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 -Dconsole.encoding=UTF-8 -Dfile.encoding=UTF-8"; "D:\program\Maven\apache-maven-3.9.12\bin\mvn.cmd" clean install -s "D:\program\Maven\settings.xml"
```

#### 常见安装位置（IDEA 项目外使用）

- Windows (默认): `C:\Program Files\Maven\apache-maven-*`
- Windows (自定义): `D:\program\Maven\apache-maven-*`
- 系统环境变量：`M2_HOME` 或 `MAVEN_HOME`

#### 版本判断方法

1. **IDEA 项目** - 优先读取 `.idea/workspace.xml` 中的 `MavenImportPreferences` 和 `MavenRunner`
2. 检查 `pom.xml` 要求的 Maven 版本（通过 `<prerequisites>` 标签）
3. 默认使用最新稳定版本

执行命令示例：
```bash
# 非 IDEA 项目：指定 JAVA_HOME 并使用 Maven 绝对路径
"C:\Program Files\Java\jdk-21\bin\java.exe" -Dmaven.multiModuleProjectProcessing="C:\Program Files\Maven\apache-maven-3.9.6" -cp "C:\Program Files\Maven\apache-maven-3.9.6\boot\plexus-classworlds-2.*.jar" org.codehaus.plexus.classworlds.launcher.Launcher clean install
```

### Node.js / npm

#### IDEA 项目配置（最高优先级）

如果项目存在 `.idea/workspace.xml`，读取 Node.js 解释器配置：
- 查找 `<component name="ProjectSettings">` 或相关的 Node 配置
- 获取已配置的 Node.js 解释器路径

#### 常见安装位置（IDEA 项目外使用）

- Windows (默认): `C:\Program Files\nodejs\node.exe`
- nvm-windows: `C:\Program Files\nvm\v*\node.exe`
- nvm (Linux/macOS): `~/.nvm/versions/node/v*/bin/node`
- 系统安装 (Linux): `/usr/bin/node`

#### 版本判断方法

1. **IDEA 项目** - 优先读取 `.idea/workspace.xml` 中的 Node.js 配置
2. 检查 `.nvmrc` 文件 - 包含 Node.js 版本号
3. 检查 `.node-version` 文件
4. 检查 `package.json` 中的 `engines.node` 字段
5. 检查 `.tool-versions` 文件（asdf）

#### 执行命令示例

```bash
# Windows 默认路径
"C:\Program Files\nodejs\node.exe" --version

# 使用 nvm 切换到指定版本后执行
nvm exec $(cat .nvmrc) npm install
```

### Python

#### IDEA 项目配置（最高优先级）

如果项目存在 `.idea/workspace.xml` 或 `.idea/misc.xml`，读取 Python 解释器配置：
- 查找 `<component name="ProjectSettings">` 或 `PythonFacet` 配置
- 获取已配置的 Python 解释器路径

#### 常见安装位置（IDEA 项目外使用）

- Windows (默认): `C:\Python3*\python.exe`, `C:\Users\<user>\AppData\Local\Programs\Python\Python3*\python.exe`
- pyenv-win: `%USERPROFILE%\.pyenv\pyenv-win\versions\*\python.exe`
- pyenv (Linux/macOS): `~/.pyenv/versions/*/bin/python`
- Anaconda: `C:\ProgramData\Anaconda3\python.exe`, `~/anaconda3/bin/python`

#### 版本判断方法

1. **IDEA 项目** - 优先读取 `.idea/workspace.xml` 中的 Python 解释器配置
2. 检查 `.python-version` 文件（pyenv）
3. 检查 `Pipfile` 或 `pyproject.toml` 中的 Python 版本要求
4. 检查 `setup.py` 或 `requirements.txt` 的版本提示
5. 检查 `.tool-versions` 文件（asdf）

#### 执行命令示例

```bash
# Windows 默认路径
"C:\Python311\python.exe" -m pip install -r requirements.txt

# 使用 pyenv 找到对应版本
pyenv exec python --version
```

## 工作流程

### 步骤 1：识别项目类型

首先判断项目使用的技术栈：
- Java 项目：存在 `pom.xml`、`build.gradle`、`.java` 文件
- Node.js 项目：存在 `package.json`
- Python 项目：存在 `requirements.txt`、`Pipfile`、`.py` 文件

### 步骤 2：读取项目配置

按优先级查找版本配置：

**最高优先级：CLAUDE.md** - 项目根目录的 `CLAUDE.md` 可能包含已配置的程序路径：

```markdown
# 项目配置

## 命令程序路径

- JAVA_HOME: D:\program\jdk21
- MAVEN_HOME: D:\program\Maven\apache-maven-3.9.6
- NODE_HOME: C:\Program Files\nodejs
- PYTHON_HOME: D:\program\python\python3.11
```

如果 `CLAUDE.md` 中存在上述配置，直接使用对应的程序路径。

**其次优先级：IDEA 项目配置** - 如果项目存在 `.idea` 目录：

1. `.idea/workspace.xml` - Maven 配置、JDK 路径、环境变量
2. `.idea/misc.xml` - JDK 版本配置（`ProjectRootManager` 组件）

**再次优先级：其他项目配置**：

**Java 项目**：
3. `pom.xml` - `<properties><java.version>`
4. `build.gradle` - `sourceCompatibility`
5. `.tool-versions` - asdf 版本

**Node.js 项目**：
3. `.nvmrc` - nvm 版本文件
4. `.node-version` - 版本文件
5. `package.json` - `engines.node`
6. `.tool-versions` - asdf 版本

**Python 项目**：
3. `.python-version` - pyenv 版本
4. `Pipfile` - `python_version`
5. `pyproject.toml` - `requires-python`
6. `.tool-versions` - asdf 版本

### 步骤 3：定位程序路径

根据识别出的版本，在常见安装位置中查找对应的程序。

**查找策略**：
1. 优先使用项目中配置文件指定的版本
2. 检查是否有环境变量指定（如 `JAVA_HOME`、`NVM_DIR`）
3. 在标准安装位置中搜索匹配版本
4. 使用版本管理工具（nvm、pyenv、asdf）的定位命令

### 步骤 4：执行命令

使用找到的程序绝对路径执行命令。

#### 传递环境变量和程序参数

**IDEA 项目中的环境变量配置位置**：

1. **Maven 项目** - 读取 `.idea/workspace.xml` 中的 `<component name="MavenRunner">`：
   - `environmentProperties` - 环境变量列表
   - 常见变量：
     - `JAVA_TOOL_OPTIONS` - Java 工具选项（如 `-Dfile.encoding=UTF-8`）
     - `MAVEN_OPTS` - Maven 运行选项（如 `-Dsun.stdout.encoding=UTF-8`）
     - `GRAALVM_HOME` - GraalVM 安装路径

2. **Java 项目** - 读取 `.idea/workspace.xml` 中的 `<component name="RunManager">`：
   - 查找运行配置中的 `env` 属性
   - 获取 `PROGRAM_PARAMETERS` 和 `VM_PARAMETERS`

3. **Node.js 项目** - 读取 `.idea/workspace.xml` 中的 Node.js 运行配置：
   - `NODE_OPTIONS` - Node.js 启动选项
   - 自定义环境变量

**执行命令时传递环境变量的方法**：

Windows PowerShell:
```powershell
# 方式 1：临时设置环境变量
$env:JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF-8"
$env:MAVEN_OPTS="-Dsun.stdout.encoding=UTF-8"
& "D:\program\Maven\apache-maven-3.9.12\bin\mvn.cmd" clean install

# 方式 2：在一行中设置
$env:JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF-8"; $env:MAVEN_OPTS="-Dsun.stdout.encoding=UTF-8"; & "D:\program\Maven\apache-maven-3.9.12\bin\mvn.cmd" clean install
```

Linux/macOS Bash:
```bash
# 方式 1：临时设置环境变量
export JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF-8"
export MAVEN_OPTS="-Dsun.stdout.encoding=UTF-8"
/path/to/mvn clean install

# 方式 2：在命令前直接传递
JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF-8" MAVEN_OPTS="-Dsun.stdout.encoding=UTF-8" /path/to/mvn clean install
```

#### 常见程序参数

**Maven 程序参数**：
- `-Dmaven.multiModuleProjectProcessing=${projectDir}` - 多模块项目处理
- `-Dmaven.repo.local=${localRepositoryPath}` - 本地仓库路径
- `-s ${settingsFile}` - 指定 settings.xml 文件
- `-B` - 批量模式（无交互）
- `-U` - 强制更新快照

**Java 程序参数**：
- `-Dfile.encoding=UTF-8` - 文件编码
- `-Xmx512m` - 最大堆内存
- `-Xms256m` - 初始堆内存
- `-Duser.language=en` - 用户语言

**Node.js 程序参数**：
- `--max-old-space-size=4096` - 最大内存限制
- `--trace-warnings` - 追踪警告

### 步骤 5：找不到程序时的处理

如果在所有配置文件中都找不到合适的程序路径，按以下步骤处理：

1. **告知用户** - 说明已尝试的配置来源（CLAUDE.md、IDEA 配置、项目配置文件等）和结果

2. **询问用户** - 提供以下选项：
   - **选项 A**: 用户提供程序路径，本次使用
   - **选项 B**: 用户提供程序路径，并保存到 `CLAUDE.md` 供后续使用
   - **选项 C**: 使用系统默认 PATH 中的程序（不推荐，可能有版本问题）

3. **保存到 CLAUDE.md 的格式** - 如果用户选择保存，使用以下格式：

```markdown
# 项目配置

## 命令程序路径

- JAVA_HOME: <用户提供的路径>
- MAVEN_HOME: <用户提供的路径>
- NODE_HOME: <用户提供的路径>
- PYTHON_HOME: <用户提供的路径>
```

4. **示例询问**：

```
我无法从以下来源找到合适的 Java 版本：
- CLAUDE.md - 未配置 JAVA_HOME
- .idea/misc.xml - 未指定具体 JDK 路径
- pom.xml - 仅指定版本 17，未指定路径

在标准安装位置也未找到 Java 17。

请问您希望：
A) 提供 Java 17 的安装路径，我本次使用
B) 提供 Java 17 的安装路径，并保存到 CLAUDE.md 供后续使用
C) 使用系统默认的 Java（可能版本不匹配）

您选择哪个选项？
```

## 特殊情况处理

### 项目没有明确的版本配置

如果项目没有任何版本配置文件：
- **Java**: 优先选择 Java 21（最新 LTS），如果项目明显较旧则选择 Java 11 或 8
- **Node.js**: 优先选择最新的 LTS 版本（20.x 或 22.x）
- **Python**: 优先选择 Python 3.11 或 3.12

### 多个项目混合

如果是多模块项目或 monorepo：
- 每个子项目可能有不同的版本要求
- 执行命令前确认当前工作目录对应的子项目配置

### 容器化项目

如果项目有 `Dockerfile` 或 `docker-compose.yml`：
- 读取 Dockerfile 中的基础镜像版本
- 使用容器中指定的版本

## 示例场景

### 场景 1：IDEA 项目运行 Java Maven 测试

```
用户：帮我运行这个 Java Maven 项目的 tests

1. 检测到 .idea/ 目录存在，判定为 IDEA 项目
2. 读取.idea/misc.xml 发现 languageLevel="JDK_21"
3. 读取.idea/workspace.xml 发现:
   - customMavenHome="C:\Program Files\Maven\apache-maven-3.9.6"
   - userSettingsFile="C:\Program Files\Maven\settings.xml"
   - MavenRunner.environmentProperties:
     - JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF-8"
     - MAVEN_OPTS="-Dsun.stdout.encoding=UTF-8 -Dfile.encoding=UTF-8"
4. 执行命令（PowerShell）：
   $env:JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF-8"
   $env:MAVEN_OPTS="-Dsun.stdout.encoding=UTF-8 -Dfile.encoding=UTF-8"
   & "C:\Program Files\Maven\apache-maven-3.9.6\bin\mvn.cmd" test -s "C:\Program Files\Maven\settings.xml"
```

### 场景 2：非 IDEA 项目运行 Maven 测试

```
用户：帮我运行这个 Java Maven 项目的 tests

1. 未检测到 .idea/ 目录
2. 检查 pom.xml 发现 <java.version>17</java.version>
3. 在标准安装位置查找 Java 17: C:\Program Files\Java\jdk-17
4. 使用默认 Maven 安装位置：C:\Program Files\Maven\apache-maven-3.9.6
5. 执行对应命令（无特殊环境变量）：
   & "C:\Program Files\Maven\apache-maven-3.9.6\bin\mvn.cmd" test
```

### 场景 3：安装 Node.js 依赖

```
用户：npm install 报错

1. 检查.nvmrc 文件，内容是 v18.16.0
2. 确认 nvm 已安装该版本：C:\Program Files\nvm\v18.16.0\
3. 执行："C:\Program Files\nodejs\node.exe" (或使用 nvm exec)
```

### 场景 4：Python 虚拟环境

```
用户：帮我安装 requirements.txt 里的依赖

1. 检查.python-version 文件，内容是 3.11.6
2. 检查是否已有虚拟环境
3. 使用 pyenv 激活对应版本并安装
   - Windows: %USERPROFILE%\.pyenv\pyenv-win\versions\3.11.6\python.exe
   - macOS/Linux: ~/.pyenv/versions/3.11.6/bin/python
```

## 错误处理

### 找不到指定的版本

如果在所有配置文件中都找不到合适的程序路径：

1. **告知用户已尝试的来源** - CLAUDE.md、IDEA 配置、项目配置文件、标准安装位置
2. **提供选项**：
   - 选项 A: 用户提供程序路径，本次使用
   - 选项 B: 用户提供程序路径，并保存到 `CLAUDE.md` 供后续使用
   - 选项 C: 使用系统默认 PATH 中的程序（不推荐）

3. **保存到 CLAUDE.md** - 如果用户选择选项 B：
   - 检查 `CLAUDE.md` 是否存在
   - 如果存在，追加程序路径配置
   - 如果不存在，创建新的 `CLAUDE.md` 并添加配置

4. **CLAUDE.md 配置格式**：
```markdown
# 项目配置

## 命令程序路径

- JAVA_HOME: D:\program\jdk21
- MAVEN_HOME: D:\program\Maven\apache-maven-3.9.6
- NODE_HOME: C:\Program Files\nodejs
- PYTHON_HOME: D:\program\python\python3.11
```

### 多个版本都符合要求

- 列出所有找到的版本
- 询问用户偏好
- 提供"保存到 CLAUDE.md"选项

### 项目配置冲突

- 告知用户发现的冲突（如 `.idea/misc.xml` 和 `pom.xml` 指定的版本不一致）
- 请求用户决策
- 提供"保存到 CLAUDE.md"选项以固定选择

## 注意事项

- 执行命令前，先输出将要使用的程序路径和版本，让用户确认
- 对于重要操作（如安装、删除），先告知用户计划使用的版本
- 如果命令执行失败，考虑是否是版本不匹配导致，尝试其他版本
- **优先使用 CLAUDE.md 中已保存的程序路径** - 这是用户明确指定的路径
- **找不到程序时主动提供"保存到 CLAUDE.md"选项** - 避免后续重复询问
- **保存路径时使用绝对路径** - 确保后续使用时路径有效
