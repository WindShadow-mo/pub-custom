---
name: ws-mybatis
description: 当编写Mybatis相关代码时使用此skill，触发场景：新增或修改Mybatis mapper接口（java接口），编写数据库实体类。
user-invocable: false
model-invocable: true
version: 1.0.0
---

# 设计原则
设计原则与项目约定的规则为互补关系，优先遵循项目内的规则。若项目内没有特别声明规则，则以此原则为主。

## 实体类设计原则
- 实体类必须与表明对应，必须以Entity结尾，如UserEntity
- 视图实体类必须以View结尾，如OrderView
- 实体类必须使用lombok注解声明，无需编写setter/getter方法，示例
  ```
  @Data
  public UserEntity{
    // 字段
  }
  ```
- 实体类字段含义为项目中的枚举时，字段类型使用枚举而非字符串，示例
  ```
  @Data
  public UserEntity{
  
    private Long id;
    private UserType type; // 此处不应该用字符串
  }
  ```

## Mapper设计原则

### 通用原则
- 命名原则：使用Mapper结尾，如UserMapper，且使用@Mapper注解修饰mapper
- 跨表查询：声明 ViewMapper（如 XxxViewMapper），维护对应的 View 实体，在 XML 中编写 SQL
- 枚举字段：使用 TypeHandler 进行枚举映射，而非字符串
- 状态字段：代表有限的状态的字段，必须使用枚举，禁止使用数字代替。如success、failed，而不是0代表成功，-1代表失败
- Mapper 参数：使用基本类型（如 `long`）而非包装类（如 `Long`）

### MyBatis-Plus或MyBatis-Flex
- SQL 写法：单表 CRUD 用 MyBatis-Plus或MyBatis-Flex的 default 方法，复杂查询用 XML写sql
