---
name: ws-java-design
description: Java 代码编写规范与设计约束。当编写、修改、重构 Java 代码时自动加载对应的编码风格、命名规范、设计原则、异常处理、注释规范。涉及 Spring 配置类、MyBatis Mapper/实体类、新建类/接口/枚举时，提供对应的设计模式与约定。确保代码符合团队规范，避免反模式。只要任务涉及 Java 代码（包括修改现有代码、新建类、调整命名、编写注释、处理异常、配置 Spring、定义 MyBatis 映射），都应该使用此 skill。
user-invocable: false
model-invocable: true
version: 1.0.0
---

# Java 设计指南

## 触发条件

编写或修改 Java 代码时加载。

## 核心原则

> **约束存在的目的是保证一致性，不要为了实现方便而妥协。**
> 修改实现以满足约束，不修改约束以适应实现。

## 文档路由

根据当前任务场景，读取对应的 design 文件：

| 场景 | 读取文件 | 说明 |
|------|---------|------|
| **修改**现有代码、做设计决策 | `design/java-design-principles.md` | 约束守护、反模式识别、设计范式 |
| **新建**类、接口、枚举、抽象类 | `design/java-class-design.md` | 类级设计模式与约定 |
| 编写**任何** Java 代码 | `design/java-coding-style.md` | 命名、格式、注释、断言、异常消息 |
| 涉及 **Spring** 配置/自动装配 | `design/java-spring-conventions.md` | 配置类、条件注解、依赖注入 |
| 涉及 **MyBatis** Mapper/实体类 | `design/java-mybatis-conventions.md` | Mapper 接口、XML、数据库实体 |

### 多场景叠加时

一次任务可能涉及多个文件，按需叠加：

```
新建一个 Spring 配置类
→ 读 design/java-class-design.md   （选类的设计模式）
→ 读 design/java-spring-conventions.md（Spring 框架约定）
→ 读 design/java-coding-style.md    （通用编码风格）

修改一个 MyBatis Mapper
→ 读 design/java-mybatis-conventions.md（MyBatis 约定）
→ 读 design/java-design-principles.md （确认不降低约束）
→ 读 design/java-coding-style.md      （通用编码风格）
```

### 不读取的场景

- 编写测试类：直接遵循 `design/java-coding-style.md` 中测试类命名规则（`Tests` 后缀），无需额外加载
- 纯文档/注释修改：仅 `design/java-coding-style.md` 的注释规范
