# Spring 框架约定

> 本文档定义 Spring Boot 项目中的框架使用约定。适用于 Spring Boot 2.7+ 项目，版本差异处会特别标注。

---

## 一、包结构约定

> **适用场景**: 中大型项目或多模块项目，按功能领域划分包结构。小型单体项目按 Controller/Service/Repository 分层也完全可以。

### 1.1 功能模块子包

当一个包下类较多时，按职责拆分子包：

| 子包 | 用途 | 适用场景 |
|------|------|---------|
| `annotation` | 自定义注解 | 有 `@EnableXxx` 或自定义声明式注解时 |
| `autoconfigure` | 自动配置类 + Properties | 需要作为 starter 供其他项目引用时 |
| `support` | 抽象基类、默认实现、包装器 | 存在多种实现或需要扩展点时 |
| `exception` | 自定义异常 | 有特定领域异常时 |
| `config` | 配置类 | 不需要自动配置，仅项目内部使用时 |
| `model` / `entity` | 领域对象 | 领域模型较复杂时 |

### 1.2 示例结构

**功能模块化结构** (适合组件库 / starter):

```
com.example.notification/
├── annotation/
│   └── EnableNotification.java
├── autoconfigure/
│   ├── NotificationAutoConfiguration.java
│   └── NotificationProperties.java
├── support/
│   ├── AbstractNotificationSender.java
│   └── NotificationSender.java
└── exception/
    └── NotificationException.java
```

**传统分层结构** (适合业务应用):

```
com.example.order/
├── controller/
├── service/
├── repository/
├── entity/
└── dto/
```

> 两种方式各有适用场景：功能模块化适合需要封装为独立组件/starter 的代码；传统分层适合业务 CRUD 应用。

---

## 二、Enable 注解

> **适用场景**: 需要用户通过一个注解即可开启某个功能模块时。
> **不适用**: 功能通过 `@AutoConfiguration` + 条件注解自动激活的场景，不需要额外的 `@EnableXxx`。

### 2.1 设计模式

```java
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@ImportAutoConfiguration(NotificationConfiguration.class)
public @interface EnableNotification {
}
```

### 2.2 约定

| 项目 | 规则 | 理由 |
|------|------|------|
| `@Target` | `ElementType.TYPE` | 标注在配置类或启动类上 |
| `@Retention` | `RetentionPolicy.RUNTIME` | 运行时读取 |
| `@Documented` | 标注 | 生成 Javadoc 时可见 |
| 导入方式 | `@ImportAutoConfiguration` | 比 `@Import` 更语义化，支持覆盖 |
| 注解体 | 通常为空 | 如需要可定义属性配合 `@AliasFor` |

### 2.3 命名规范

- 注解名: `@Enable<功能名>`
- 配置类: `<功能名>Configuration`

---

## 三、Configuration 配置类

> **适用场景**: 定义 Bean、组织配置逻辑。
>
> `@Configuration` 本身标注了 `@Component`，因此配置类也是组件。下面的可见性规则同时适用于两者。

### 3.1 `proxyBeanMethods = false`

> **推荐**: 大多数配置类设置 `proxyBeanMethods = false`。
> **理由**: 避免为 `@Bean` 方法生成 CGLIB 代理，减少启动开销。
> **例外**: 如果 `@Bean` 方法之间需要互相调用来复用 Bean 实例（lite 模式），则需要 proxy（默认 true）。

```java
@Configuration(proxyBeanMethods = false)
class NotificationConfiguration {

    @Bean
    @Role(BeanDefinition.ROLE_INFRASTRUCTURE)
    @ConditionalOnMissingBean(NotificationSender.class)
    public static NotificationSender defaultNotificationSender() {
        return new DefaultNotificationSender();
    }
}
```

### 3.2 配置类约定

| 注解 | 可见性 | 说明 |
|------|--------|------|
| `@Configuration` | 包级可见 | 配置类是内部实现，用户通过 `@EnableXxx` 间接使用 |
| `@Component` | 包级可见 | 同上。`@Configuration` 继承自 `@Component`，规则一致 |
| `@Component` (需跨包引用) | `public` | 如测试中需要显式 `@Import` 或跨包扫描时 |

| 项目 | 推荐 | 适用场景 |
|------|------|---------|
| `@Bean` 方法 | `public static` | static 避免实例化配置类，提升启动速度 |
| 基础设施 Bean | `@Role(ROLE_INFRASTRUCTURE)` | AOP 切面、拦截器等框架级 Bean |
| 默认实现 | `@ConditionalOnMissingBean` | 提供默认 Bean，允许用户覆盖 |

> **可见性选择逻辑**: 包级可见是默认值。只有当类需要被其他包直接引用（测试导入、跨包依赖）时才用 `public`。

---

## 四、AutoConfiguration 自动配置

> **适用场景**: 开发 Spring Boot Starter 或需要按条件自动装配的模块。
> **不适用**: 普通业务应用的配置类，直接用 `@Configuration` 即可。

### 4.1 自动配置类

```java
@AutoConfiguration
@ConditionalOnClass(NotificationService.class)
@ConditionalOnProperty(prefix = "app.notification", name = "enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(NotificationProperties.class)
public class NotificationAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public static NotificationService notificationService(NotificationProperties properties) {
        return new DefaultNotificationService(properties);
    }
}
```

### 4.2 约定

| 项目 | 规则 |
|------|------|
| 注解 | `@AutoConfiguration`（Spring Boot 2.7+）；更早版本用 `@Configuration` + `@EnableAutoConfiguration` |
| 条件注解 | 按需组合 `@ConditionalOnClass`、`@ConditionalOnProperty`、`@ConditionalOnMissingBean` 等（全版本通用） |
| Properties 绑定 | `@EnableConfigurationProperties(XxxProperties.class)`（全版本通用） |
| `@Bean` 方法 | 推荐 `static`（不依赖实例状态） |
| 依赖注入 | 通过方法参数注入 |

### 4.3 注册方式

**Spring Boot 2.7+ / 3+**: `META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports`

```
com.example.notification.autoconfigure.NotificationAutoConfiguration
```

**Spring Boot 2.0 ~ 2.6**: `META-INF/spring.factories`

```properties
org.springframework.boot.autoconfigure.EnableAutoConfiguration=\
com.example.notification.autoconfigure.NotificationAutoConfiguration
```

> `AutoConfiguration.imports` 从 2.7 开始支持，3.0 起 `spring.factories` 中的自动配置注册被移除。新项目直接用 imports 文件；2.0~2.6 的旧项目用 spring.factories。

---

## 五、Properties 类

> **适用**: [AutoConfiguration 场景] 配置绑定。普通 `@Configuration` 中简单的 `@Value` 也可以。

### 5.1 基本结构

```java
@Validated
@ConfigurationProperties("app.notification")
public class NotificationProperties {

    private boolean enabled = true;
    private String endpoint;
    private Map<String, @Valid ChannelProperties> channels = Collections.emptyMap();

    // getter/setter
}
```

### 5.2 约定

| 项目 | 推荐 | 理由 |
|------|------|------|
| 校验 | `@Validated` | 启动时校验配置合法性，快速失败 |
| 嵌套校验 | `@Valid` | 级联校验嵌套对象的字段 |
| 集合默认值 | `Collections.emptyMap()` / `emptyList()` | 避免 null，简化调用方代码 |
| 校验注解 | `@NotBlank`, `@NotNull`, `@Min` 等 | Spring Boot 3+ 用 `jakarta.validation.*`；2.x 用 `javax.validation.*` |
| 共享字段 | 继承基类 | 多个 Properties 类有公共字段时 |
| Lombok | 可用 `@Data` 替代手写 getter/setter | 项目风格统一即可 |

### 5.3 配置前缀

> 前缀的选择取决于项目类型，没有统一标准，重要的是项目内一致。

| 场景 | 常见前缀模式 | 示例 |
|------|-------------|------|
| Spring Boot Starter | `spring.<模块>` 或自定义前缀 | `spring.mail`, `app.notification` |
| 业务应用 | `app.<模块>` | `app.order`, `app.auth` |
| 第三方服务对接 | `app.third.<服务>` 或直接用服务名 | `app.third.wechat`, `wechat.mp` |

---

## 六、条件注解

> **核心判断**: 同一个条件表达式出现 2 次及以上 → 封装；只出现 1 次 → 直接写。
>
> **不要提前封装** — 等条件真正重复时再提取，YAGNI。

### 6.1 直接使用（默认）

单个 `@ConditionalOnXxx` 不需要封装为自定义注解：

```java
@AutoConfiguration
@ConditionalOnClass(NotificationService.class)  // 直接用
@ConditionalOnProperty(prefix = "app.notification", name = "enabled",
        havingValue = "true", matchIfMissing = true)
public class NotificationAutoConfiguration {
}
```

### 6.2 封装为自定义注解

> **触发条件**: 同一组条件注解在 2 个及以上类/方法上重复出现。

```java
// 封装前: 两处都写了相同的 @ConditionalOnProperty
@ConditionalOnProperty(prefix = "app.notification", name = "enabled",
        havingValue = "true", matchIfMissing = true)
public @interface ConditionalOnNotification {
}
```

封装后使用方只需一个注解：

```java
@AutoConfiguration
@ConditionalOnNotification  // 语义清晰，且条件集中在一处维护
public class NotificationAutoConfiguration {
}
```

### 6.3 约定

| 项目 | 规则 |
|------|------|
| 标注位置 | `TYPE` 和 `METHOD`（根据实际需要） |
| 命名 | `@ConditionalOn<功能名>` |
| `@Documented` | 标注 |
| 封装时机 | 条件重复 ≥ 2 处时才封装，不要预防性封装 |

### 6.3 常用条件注解速查

| 条件 | 注解 | 适用场景 |
|------|------|---------|
| 类路径存在 | `@ConditionalOnClass` | 可选依赖存在时才生效 |
| Bean 缺失 | `@ConditionalOnMissingBean` | 提供默认实现 |
| 配置项 | `@ConditionalOnProperty` | 通过配置开关控制 |
| 类路径缺失 | `@ConditionalOnMissingClass` | 某依赖不存在时才生效 |
| 组合条件 | 多个 `@Conditional*` 叠加 | 所有条件都满足时生效 (AND) |

---

## 七、依赖注入

### 7.1 构造器注入（推荐）

> **理由**: 依赖不可变（`final`）、明确（构造参数）、可测试（直接 new）。

```java
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final CacheService cacheService;
}
```

### 7.2 配置类中的注入

通过 `@Bean` 方法参数注入：

```java
@AutoConfiguration
public class ServiceAutoConfiguration {

    @Bean
    public UserService userService(UserRepository userRepository,
                                    CacheService cacheService) {
        return new UserService(userRepository, cacheService);
    }
}
```

### 7.3 字段注入

> **不推荐**: 依赖不可见（非 final）、隐藏依赖关系、难以单元测试。
> **例外**: 测试类中用 `@Autowired` 注入 Mock 或测试用 Bean 可以接受。

```java
// 业务代码: 不推荐
// ❌
@Autowired
private UserRepository userRepository;

// ✅
private final UserRepository userRepository;
```

---

## 八、其他约定

### 8.1 Bean 定义角色

> **适用**: 框架级 Bean（AOP、拦截器、后处理器等）。
> **不适用**: 业务 Bean 不需要标注，默认 `ROLE_APPLICATION`。

```java
@Bean
@Role(BeanDefinition.ROLE_INFRASTRUCTURE)
public Advisor transactionAdvisor() {
    return new TransactionInterceptor();
}
```

| 角色 | 用途 |
|------|------|
| `ROLE_APPLICATION` | 业务 Bean（默认） |
| `ROLE_INFRASTRUCTURE` | 基础设施 Bean（AOP、拦截器等） |
| `ROLE_SUPPORT` | 支撑 Bean（较少使用） |

### 8.2 Spring 工具类

> 已在 Spring 依赖中的项目，优先使用 Spring 工具类，避免引入额外依赖做同样的事。

| 工具类 | 用途 |
|--------|------|
| `Assert` | 前置条件检查 |
| `StringUtils` | 字符串处理 |
| `CollectionUtils` | 集合处理 |
| `ClassUtils` | 类加载与反射 |
| `ReflectionUtils` | 反射操作 |
| `AnnotationUtils` | 注解处理 |
| `ResolvableType` | 泛型解析 |

### 8.3 配置属性元数据

> **推荐**: Starter 项目中引入，用户在 IDE 中获得配置提示。
> **不适用**: 普通业务应用不需要。

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-configuration-processor</artifactId>
    <optional>true</optional>
</dependency>
```

---

## 九、设计原则总结

| # | 原则 | 适用条件 |
|---|------|---------|
| 1 | 包结构按职责拆分 | 功能模块化 / starter 场景；业务应用按传统分层即可 |
| 2 | Enable 注解作为模块入口 | 需要用户显式开启功能时；自动激活的模块不需要 |
| 3 | `proxyBeanMethods = false` | 大多数场景；`@Bean` 方法间互相调用时需要 proxy |
| 4 | `@Bean` 方法 static | 配置类无状态时；需要调用其他 `@Bean` 方法时不能 static |
| 5 | `@Configuration` / `@Component` 包级可见 | 默认包级可见；需跨包引用（测试导入等）时用 `public`。`@Configuration` 继承自 `@Component`，规则一致 |
| 6 | Properties 启用校验 | 配置项多或有必填项时；简单配置 `@Value` 足够 |
| 7 | 条件注解封装 | 同一条件出现 ≥ 2 次时封装为 `@ConditionalOn<功能名>`；单次使用直接写 `@ConditionalOnXxx`，不要预防性封装 |
| 8 | 构造器注入 | 业务代码推荐；测试代码 `@Autowired` 可以接受 |
