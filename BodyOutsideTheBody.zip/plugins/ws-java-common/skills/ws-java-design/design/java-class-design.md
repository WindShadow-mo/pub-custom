# Java 类设计约定

> 本文档定义各类 Java 元素的设计模式与约定。每条约定附带适用场景，根据实际需要选择，不强制套用。

---

## 一、POJO 类

> **适用场景**: 数据传输对象 (DTO/VO/BO)、配置绑定对象、表单对象等以数据承载为主的类。

### 1.1 标准 POJO — Lombok `@Data` + `@ToString`

```java
@Data
@ToString
public class UserDTO {
    private Long id;
    private String name;
    private Integer age;
}
```

- 使用 `@Data` 生成 getter/setter/equals/hashCode/toString
- 使用 `@ToString` 可覆盖 `@Data` 自带的 toString（如需要 `callSuper=true`）
- **不要**同时手动写 getter/setter，避免与 Lombok 生成冲突

### 1.2 record — 不可变数据载体

> **前提**: Java 16+。
> **适用场景**: 数据创建后不需要修改的场景，如 API 响应体、方法多返回值、Map 的 key。
> **不适用**: 需要 setter 的 DTO、需要继承的类、JPA 实体（多数 JPA 实现不直接支持 record）。

```java
public record UserResponse(Long id, String name) {
}
```

record 天生不可变（字段隐式 `final`），自带 equals/hashCode/toString，适合替代简单的纯数据类。

### 1.3 组件型代码 — 手写 getter

> **适用场景**: 框架组件、工具库等公共 API 代码。
> **原因**: 组件代码的 API 透明度比简洁性更重要，手写可精确控制暴露哪些方法、字段的语义。

```java
public class ComponentConfig {
    private final String name;
    private final int timeout;

    public ComponentConfig(String name, int timeout) {
        this.name = name;
        this.timeout = timeout;
    }

    public String getName() { return name; }
    public int getTimeout() { return timeout; }
}
```

---

## 二、枚举类

> **适用场景**: 有限固定值集合（状态、类型、级别等）。

### 2.1 字段 `final`

枚举字段应当是 `final`，枚举实例是不可变的：

```java
public enum OrderStatus {
    PENDING(1, "待支付"),
    PAID(2, "已支付");

    private final int code;
    private final String description;

    OrderStatus(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() { return code; }
    public String getDescription() { return description; }
}
```

### 2.2 查找方法 — 按场景选择

#### 场景 A: 查找属性有唯一性约束

> **适用**: 通过 code/id 反查枚举，且 code 保证唯一。

使用静态 Map + `merge()` 在初始化时校验唯一性：

```java
private static final Map<Integer, OrderStatus> CODE_MAP;

static {
    Map<Integer, OrderStatus> map = new HashMap<>();
    for (OrderStatus status : values()) {
        if (map.merge(status.code, status, (a, b) -> {
            throw new IllegalStateException("Duplicate code: " + status.code);
        }) == null) {
            throw new IllegalStateException("Null key: " + status.code);
        }
    }
    CODE_MAP = Collections.unmodifiableMap(map);
}

// 严格查找: 找不到抛异常
public static OrderStatus of(int code) {
    OrderStatus status = CODE_MAP.get(code);
    if (status == null) {
        throw new IllegalArgumentException("Unknown code: " + code);
    }
    return status;
}

// 宽松查找: 找不到返回 Optional.empty()
public static Optional<OrderStatus> resolve(int code) {
    return Optional.ofNullable(CODE_MAP.get(code));
}
```

**为什么用 `merge()`**: 启动时立即暴露重复 key 的 bug，而不是运行时静默返回错误结果。

#### 场景 B: 查找属性无唯一性

> **适用**: 多个枚举值共享同一个属性值（如多个状态同属一个分组）。
> **做法**: 不需要 Map，直接用 `for` 遍历或 `stream().filter()`。

```java
public enum TaskPriority {
    LOW(1), NORMAL(2), HIGH(3), URGENT(3);  // HIGH 和 URGENT 共享 level=3

    private final int level;

    // 返回所有匹配项
    public static List<TaskPriority> ofLevel(int level) {
        return Arrays.stream(values())
                .filter(p -> p.level == level)
                .toList();
    }
}
```

#### 场景 C: 不需要查找

> **适用**: 枚举只用于遍历或 switch，不需要反查。
> **做法**: 不写查找方法。

```java
public enum Season { SPRING, SUMMER, AUTUMN, WINTER }
```

---

## 三、接口与函数式接口

### 3.1 普通接口

> **适用场景**: 定义服务契约、抽象能力。

```java
public interface UserService {
    User findById(Long id);
    List<User> findAll();
}
```

默认方法用于提供便利重载，但不要在接口中堆砌业务逻辑。

### 3.2 函数式接口

> **前提**: 接口有且仅有一个抽象方法（可有多个 default/static 方法）。
> **适用场景**: 回调、策略、Lambda 表达式目标类型。

```java
@FunctionalInterface
public interface MethodPeeper<T> {
    void peek(T value);
}
```

`@FunctionalInterface` 是编译期约束：如果接口意外变成多方法，编译器会报错。

### 3.3 泛型约束

> **适用场景**: 类型之间有依赖关系，需要在编译期保证。

```java
// E 必须是实现了 EnumValue<T> 的枚举
public interface EnumValueConverter<E extends Enum<? extends EnumValue<T>>, T> {
    T convert(E enumValue);
    E reverse(T value);
}
```

不要为了"灵活"而用 `<T>` 代替具体类型 — 能用具体类型就不用泛型。

---

## 四、抽象类 (模板方法模式)

> **适用场景**: 多个子类共享相同的执行流程，只有某些步骤不同。
> **不适用**: 只有一两个子类且差异很大时，用策略模式或直接写具体类更简单。

### 4.1 设计模式

```java
public abstract class AbstractHandler {

    // 模板方法: 定义流程, 子类不应覆盖
    public final void handle(Request request) {
        checkRequest(request);    // 共享校验
        doHandle(request);        // 委托子类
    }

    // 共享校验: 子类可按需覆盖
    protected void checkRequest(Request request) {
        Assert.notNull(request, "Request must not be null");
    }

    // 子类实现
    protected abstract void doHandle(Request request);
}
```

### 4.2 命名约定

| 方法类型 | 命名规则 | 含义 |
|---------|---------|------|
| 模板方法 | 直接命名 `handle()` | 公共入口，通常 `final` |
| 校验方法 | `checkXxx()` | 共享的前置校验 |
| 委托方法 | `doXxx()` | 子类覆盖的具体实现 |

### 4.3 何时用 `final`

- 模板方法本身：加 `final` 防止子类破坏流程
- 校验方法：如果不希望子类跳过校验，也加 `final`
- 如果子类确实需要跳过某步校验，去掉 `final` 并提供 `protected` 覆盖

---

## 五、常量定义

> **适用场景**: 一组逻辑相关的固定值（magic number / magic string 的归宿）。

### 5.1 常量接口 vs 常量类 vs 枚举

| 方式 | 适用 | 不适用 |
|------|------|--------|
| **常量接口** | 纯常量集合，无行为 | 需要命名空间隔离时（实现接口的类会"污染"类型） |
| **常量类** (`final class` + 私有构造) | 需要控制实例化、避免被 implements | 简单场景下略显冗余 |
| **枚举** | 常量有明确的类型归属和行为 | 只是几个不相关的数字/字符串 |

**常量接口**:

```java
public interface NetworkConstants {
    String LOCALHOST = "127.0.0.1";
    int DEFAULT_PORT = 8080;
}
```

**常量类** (如果担心接口污染):

```java
public final class NetworkConstants {
    private NetworkConstants() {}
    public static final String LOCALHOST = "127.0.0.1";
    public static final int DEFAULT_PORT = 8080;
}
```

**枚举** (常量有类型归属):

```java
public enum Protocol {
    HTTP(80), HTTPS(443), SSH(22);
    private final int defaultPort;
    Protocol(int defaultPort) { this.defaultPort = defaultPort; }
    public int getDefaultPort() { return defaultPort; }
}
```

### 5.2 命名规则

- 全大写下划线分隔: `MAX_RETRY_COUNT`
- 语义明确，避免缩写: `TIMEOUT_MILLISECONDS` 而非 `TO_MS`

---

## 六、异常类

> **适用场景**: 需要表达特定业务语义或区分错误类型时，才创建自定义异常。
> **不适用**: 直接用 `IllegalArgumentException` / `IllegalStateException` / `RuntimeException` 能表达的场景，不必新建异常类。

### 6.1 标准构造函数

根据实际需要选择，不强制提供全部 4 个：

```java
public class BizException extends RuntimeException {

    // 最常用: 必须有
    public BizException(String message) {
        super(message);
    }

    // 需要包装原始异常时: 推荐有
    public BizException(String message, Throwable cause) {
        super(message, cause);
    }

    // 以下按需添加 ↓

    // 只需要 cause，不需要自定义消息
    public BizException(Throwable cause) {
        super(cause);
    }

    // 需要控制 suppression / stacktrace 时 (少见)
    public BizException(String message, Throwable cause,
                        boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
```

**经验法则**: 前两个构造函数（message, message+cause）覆盖 90% 的场景。如果确定不会用到后两个，可以不写。

### 6.2 异常家族

> **适用**: 多个异常共享基类行为（如统一的错误码处理），或需要一个 catch 点捕获整类异常。
> **不适用**: 只有一个异常类时，不需要抽象基类。

```java
public abstract class RestrictionException extends RuntimeException {
    public RestrictionException(String message) { super(message); }
    public RestrictionException(String message, Throwable cause) { super(message, cause); }
}

public class FrequencyRestrictionException extends RestrictionException {
    public FrequencyRestrictionException(String message) { super(message); }
}
```

---

## 七、内部类与嵌套类型

> **适用场景**: 类型只在外部类内部使用，不应暴露给外部。

### 7.1 基本原则

- 内部类必须是 `private static`（除非确实需要持有外部类引用）
- 简单数据容器优先用 `record`（Java 16+）
- 如果内部类逻辑复杂到需要独立文件，说明它不该是内部类

### 7.2 资源清理场景 (Java 9+)

> **前提**: `java.lang.ref.Cleaner` 需要 Java 9+。
> **适用**: 非 `AutoCloseable` 或不可靠关闭的资源（如临时文件、native 资源）。
> **不适用**: 实现了 `Closeable/AutoCloseable` 的资源，用 try-with-resources 更直接。

```java
public class TemporaryResource implements AutoCloseable {
    private final Cleaner.Cleanable cleanable;

    public TemporaryResource() {
        this.cleanable = Cleaner.create().register(this, new InnerCleaner());
    }

    @Override
    public void close() {
        cleanable.clean();
    }

    // Java 16+: 用 record 封装清理逻辑
    private record InnerCleaner() implements Runnable {
        @Override
        public void run() {
            // 清理临时文件
        }
    }
}
```

Java 16 以下用 `private static class` 替代 `record`。

---

## 八、方法组织顺序

> **适用**: 中大型类（>200 行）。小类（<100 行）按逻辑就近排列即可。

### 8.1 推荐顺序

```
1. 静态常量 / 静态字段
2. 实例字段
3. 构造函数 (无参优先)
4. 公共方法
5. 受保护方法
6. 私有方法
7. 静态辅助方法
```

### 8.2 Section 分隔符

> **适用**: 方法较多（>10 个）且有明确的功能分组时。
> **不适用**: 小类或方法本身就很少时，加分隔符反而噪音。

```java
public class SshClient {

    // ~exec
    // ==================================

    public void exec(String command) { }

    // ~shell
    // ==================================

    public void shell() { }

    // ~forward
    // ==================================

    public void forward() { }
}
```

---

## 九、设计原则总结

| # | 原则 | 适用条件 |
|---|------|---------|
| 1 | POJO 用 Lombok `@Data`，组件代码可手写 | 组件 API 需要精确控制暴露面 |
| 2 | record 用于不可变数据载体 | Java 16+，且不需要 setter/继承 |
| 3 | 枚举字段 `final` | 始终适用 |
| 4 | 枚举查找方法按场景选择 | 唯一属性用 Map+merge，非唯一用 filter，不需要就不写 |
| 5 | 函数式接口加 `@FunctionalInterface` | 确实只有一个抽象方法时 |
| 6 | 模板方法: `checkXxx()` + `doXxx()` | 多子类共享相同流程时 |
| 7 | 常量按类型选择接口/类/枚举 | 无归属用接口或类，有类型归属用枚举 |
| 8 | 异常构造函数按需添加 | message + message+cause 覆盖大多数场景 |
| 9 | 内部类 `private static` | 只在外部类内使用 |
| 10 | 方法顺序和分隔符 | 中大型类 (>200 行) 推荐，小类随意 |
