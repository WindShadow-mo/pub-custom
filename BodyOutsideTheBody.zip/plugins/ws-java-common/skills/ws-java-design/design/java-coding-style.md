# Java 编码风格规范

> 本规范适用于所有 Java 代码开发，强调简洁、一致、可读。

---

## 一、命名规范

### 1.1 基本规则

| 元素 | 风格 | 示例 |
|------|------|------|
| 类/接口/枚举 | UpperCamelCase | `UserService`, `OrderStatus` |
| 方法/变量 | lowerCamelCase | `getUserById`, `orderCount` |
| 常量 | UPPER_SNAKE_CASE | `MAX_RETRY_COUNT` |
| 包 | 全小写，单英文单词 | `ws.spring.aop` |

### 1.2 特殊前缀/后缀

| 类型 | 前缀/后缀 | 示例 |
|------|-----------|------|
| 抽象类 | `Abstract` 或 `Base` | `AbstractHandler`, `BaseService` |
| 默认实现 | `Default` 或 `Simple` | `DefaultLogger`, `SimpleCache` |
| 异常类 | `Exception` 结尾 | `BizException` |
| 测试类 | `Tests` 结尾 | `UserServiceTests` |
| 实现类 | `Impl` 结尾 | `UserServiceImpl` |
| Properties 类 | `Properties` 结尾 | `AppProperties` |
| Configuration 类 | `Configuration` 结尾 | `WebConfiguration` |
| Constants 接口 | `Constants` 结尾 | `CacheConstants` |

---

## 二、格式规范

### 2.1 基础格式

- **缩进**: 4 个空格
- **行宽**: 最大 120 字符
- **括号风格**:
  - 多行代码块: `{` 后留空行
  - 单行代码块: `{` 后不留空行

### 2.2 空格规则

- 运算符两侧加空格: `a + b`, `x == y`
- 逗号后加空格: `method(a, b, c)`
- 关键字后加空格: `if (condition)`, `for (int i = 0; ...)`

### 2.3 强制大括号

单行 `if/else/for/while` 必须加大括号:

```java
// ✅ 正确
if (condition) {
    doSomething();
}

// ❌ 错误
if (condition)
    doSomething();
```

### 2.4 方法体格式

```java
// 单行方法: 不留空行
public boolean isEmpty() { return size == 0; }

// 多行方法: { 后留空行
public void process() {

    validate();
    execute();
    cleanup();
}
```

---

## 三、导入顺序

按以下顺序分组，组间空一行:

1. `org.*` (Spring, Apache 等)
2. 项目内部包 (`ws.spring.*`)
3. `java.*` / `javax.*` (JDK)

**禁止通配符导入** (除 `java.util.*` 外):

```java
// ✅ 正确
import java.util.List;
import java.util.Map;

// ❌ 错误
import java.util.*;
```

---

## 四、注释规范

### 4.1 类级 Javadoc

每个类/接口/枚举应有 Javadoc 描述其用途：

```java
/**
 * 用户服务
 *
 * @version 2024-01-15
 */
public class UserService { }
```

**`@author` 标注规则**: 仅当项目上下文（如 `CLAUDE.md`、项目文档等）中明确指定了作者信息时，才添加 `@author` 标签；否则不标注。

```java
// 项目上下文指定了作者 → 标注
/**
 * @author WindShadow
 * @version 2024-01-15
 */

// 项目上下文未指定作者 → 不标注
/**
 * @version 2024-01-15
 */
```

### 4.2 注释原则

- **复杂代码必须注释**: 解释"为什么"而非"做什么"
- **简单代码不注释**: 让代码自文档化
- **公共 API 必须注释**: 方法签名、参数、返回值、异常
- **内部方法不强制**: 私有方法仅在复杂时注释

---

## 五、断言与参数校验

### 5.1 断言工具

| 场景 | 工具 | 理由 |
|------|------|------|
| 业务方法前置条件 | Spring `Assert` | 消息可自定义，抛出 `IllegalArgumentException`，语义清晰 |
| 构造器 null 检查 | `Objects.requireNonNull` | 无 Spring 依赖，适合构造器场景，返回非 null 值可直接赋值 |
| 不应到达的分支 | `throw new IllegalStateException` | 程序逻辑错误，不是参数问题 |
| 测试中的前置假设 | JUnit `Assertions` / AssertJ | 测试框架自带，失败时报告为测试失败 |

**Spring Assert 常用方法**:

```java
import org.springframework.util.Assert;

Assert.notNull(user, "User must not be null");
Assert.hasText(name, "Name must not be empty");
Assert.isTrue(count > 0, "Count must be positive");
Assert.notEmpty(list, "List must not be empty");
```

**Objects.requireNonNull 适用场景**: 构造器注入、工具类静态工厂方法：

```java
// 构造器: 无 Spring 依赖，且可以链式赋值
this.repository = Objects.requireNonNull(repository, "Repository must not be null");

// 静态工厂
public static Config of(String name) {
    return new Config(Objects.requireNonNull(name));
}
```

### 5.2 构造器空值检查

使用 `Objects.requireNonNull`:

```java
public UserService(UserRepository repository) {
    this.repository = Objects.requireNonNull(repository, "Repository must not be null");
}
```

### 5.3 参数校验位置

重载链中只在**最终方法**校验一次:

```java
// ✅ 正确: 只在最终方法校验
public void process(String data) {
    process(data, DEFAULT_OPTIONS);
}

public void process(String data, Options options) {
    Assert.notNull(data, "Data must not be null");
    Assert.notNull(options, "Options must not be null");
    doProcess(data, options);
}

// ❌ 错误: 每个重载都校验
public void process(String data) {
    Assert.notNull(data, "Data must not be null");  // 重复校验
    process(data, DEFAULT_OPTIONS);
}
```

---

## 六、空安全注解

### 6.1 版本选择

- **Spring Boot 4+**: `org.jspecify.annotations.Nullable`
- **Spring Boot 3-**: `org.springframework.lang.Nullable`

### 6.2 使用场景

```java
// 可能返回 null
@Nullable
public User findUser(Long id) { }

// 接受 null 参数
public void setUser(@Nullable User user) { }

// 必须非空
public void process(@NonNull String data) { }
```

**选择性使用**: 只在真正有意义的地方标注，不要过度使用。

---

## 七、异常处理

### 7.1 异常消息语言

| 异常类型 | 消息语言 | 示例 |
|---------|---------|------|
| 标准异常 (`IllegalArgumentException` 等) | 英文 | `"User must not be null"` |
| 组件/框架异常 | 英文 | `"Connection timeout"` |
| 业务异常 | 项目自然语言（默认中文），或 i18n 错误码 | `"用户不存在"` 或 `"ERR_USER_NOT_FOUND"` |

> **业务异常语言说明**: 业务异常的消息面向终端用户或运维人员，应使用项目的自然语言。中文项目默认中文；如果项目面向国际化，则使用 i18n 错误码，通过消息模板解析为对应语言。

### 7.2 自定义异常

继承 `RuntimeException`, 提供 4 个标准构造函数:

```java
public class BizException extends RuntimeException {

    public BizException(String message) {
        super(message);
    }

    public BizException(String message, Throwable cause) {
        super(message, cause);
    }

    public BizException(Throwable cause) {
        super(cause);
    }

    public BizException(String message, Throwable cause,
                        boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
```

---

## 八、设计守护元规则

> **核心原则**: 不为方便降低设计标准

### 8.1 反模式识别

警惕以下借口:

- ❌ "为了兼容性"
- ❌ "放松条件"
- ❌ "可选的"
- ❌ "不满足时跳过"
- ❌ "添加例外"

### 8.2 正确做法

遇到设计冲突时:

1. **停下来思考**: 是否真的需要破坏设计?
2. **寻找替代方案**: 有没有不破坏设计的方法?
3. **修复实现**: 调整实现而非降低标准
4. **记录决策**: 如果确实需要例外,记录原因

---

## 九、其他约定

### 9.1 JSON 序列化

- **推荐使用 Jackson** (`com.fasterxml.jackson`)
- 避免引入 Fastjson、Gson 等其他 JSON 库，保持项目序列化方案统一

### 9.2 资源清理

使用 `java.lang.ref.Cleaner` 管理非 Closeable 资源:

```java
public class ResourceHolder {
    private static final Cleaner cleaner = Cleaner.create();
    private final Cleaner.Cleanable cleanable;

    public ResourceHolder() {
        this.cleanable = cleaner.register(this, new State());
    }

    private record State() implements Runnable {
        @Override
        public void run() {
            // 清理逻辑
        }
    }
}
```

### 9.3 方法组织顺序

类中方法按以下顺序排列:

1. 静态常量/字段
2. 实例字段
3. 构造函数 (无参优先)
4. 公共方法
5. 受保护方法
6. 私有方法
7. 静态辅助方法

使用 `// ~sectionName` 分隔符:

```java
// ~init
// ==================================

public void init() { }

// ~process
// ==================================

public void process() { }
```
