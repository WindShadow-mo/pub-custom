# MyBatis 约定

> 本文档定义 MyBatis 生态下的编码约定，覆盖 **MyBatis**（原生）、**MyBatis-Plus**、**MyBatis-Flex** 三个框架。
> 不同框架的约定会用标记区分：`[MP]` = MyBatis-Plus, `[MF]` = MyBatis-Flex, `[ALL]` = 三者通用。

---

## 一、实体类

> **适用**: [ALL] 所有 MyBatis 项目。

### 1.1 命名规范

| 类型 | 后缀 | 示例 | 说明 |
|------|------|------|------|
| 标准实体 | `Entity` | `UserEntity` | 映射单张表 |
| 视图实体 | `View` | `UserView` | 跨表查询的结果映射 |
| DTO | `DTO` | `UserDTO` | 服务间/层间数据传输 |
| VO | `VO` | `UserVO` | 面向前端的视图对象 |

### 1.2 实体类结构

**MyBatis-Plus** `[MP]`:

```java
@Data
@TableName("user")
public class UserEntity {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String username;
    private String email;
    private UserStatus status;      // 枚举类型
    private LocalDateTime createdAt;
}
```

**MyBatis-Flex** `[MF]`:

```java
@Data
@Table("user")
public class UserEntity {

    @Id(keyType = KeyType.Auto)
    private Long id;

    private String username;
    private String email;
    private UserStatus status;
    private LocalDateTime createdAt;
}
```

**原生 MyBatis** `[ALL]`: 无框架注解，实体只是纯 POJO，字段映射在 XML 中通过 `resultMap` 或 `resultType` 配置。

### 1.3 字段类型约定

> 以下推荐适用于大多数业务系统。极端性能场景（如高频交易、批量导入）可按需调整。

| 字段类型 | 推荐类型 | 理由 | 注意事项 |
|---------|----------|------|---------|
| 主键 | `Long` | 允许 null 区分"未赋值"与"值为 0" | 分布式 ID 场景用 `String` 或 `Long` |
| 状态/类型 | 枚举类型 | 代码可读性强，编译期约束 | 需配置 TypeHandler（见 1.4） |
| 时间 | `LocalDateTime` | Java 8+ 标准时间 API | 只需日期用 `LocalDate` |
| 金额 | `BigDecimal` | 精确计算，无精度丢失 | 禁止 `double`/`float` |
| 布尔 | `Boolean` | 允许 null 表示"未知" | 数据库 `tinyint(1)` 对应 |

### 1.4 枚举字段

> **推荐**: 状态、类型等有明确语义的字段使用枚举，避免魔法数字/字符串散落在业务代码中。
> **例外**: 枚举值频繁变动（如第三方回调状态码）时，用 `Integer`/`String` + 常量类更灵活。

**框架枚举支持**:

| 框架 | 枚举 TypeHandler | 配置方式 |
|------|-----------------|---------|
| MyBatis-Plus | `MybatisEnumTypeHandler` | 全局配置 或 字段 `@EnumValue` |
| MyBatis-Flex | 内置支持 | 字段 `@Column(isEnumValue = true)` |
| 原生 MyBatis | 需自定义或注册 | `<typeHandler>` 在 resultMap 中指定 |

**MyBatis-Plus 枚举定义**:

```java
public enum OrderStatus {
    PENDING(1, "待支付"),
    PAID(2, "已支付");

    @EnumValue   // 标记数据库存储值
    private final int code;

    private final String description;
    // 构造函数、getter 省略
}
```

**MyBatis-Plus 全局配置**:

```yaml
mybatis-plus:
  configuration:
    default-enum-type-handler: com.baomidou.mybatisplus.core.handlers.MybatisEnumTypeHandler
```

---

## 二、Mapper 接口

> **适用**: [ALL]

### 2.1 命名规范

| 类型 | 后缀 | 用途 | 适用场景 |
|------|------|------|---------|
| 标准 Mapper | `Mapper` | 单表 CRUD | 有增强框架时继承 BaseMapper |
| 视图 Mapper | `ViewMapper` | 跨表查询 | 多表 JOIN、聚合查询 |

### 2.2 基本结构

**有增强框架时** `[MP]`/`[MF]`:

```java
@Mapper
public interface UserMapper extends BaseMapper<UserEntity> {
    // BaseMapper 提供 insert/selectById/updateById/deleteById 等

    // 自定义查询
    UserEntity selectByUsername(@Param("username") String username);
}
```

**原生 MyBatis**:

```java
@Mapper
public interface UserMapper {
    UserEntity selectById(@Param("id") long id);
    List<UserEntity> selectAll();
    int insert(UserEntity entity);
    int updateById(UserEntity entity);
    int deleteById(@Param("id") long id);
}
```

### 2.3 参数类型约定

> **推荐**: 必填参数（主键、必填查询条件）用基本类型。
> **理由**: 基本类型编译期保证非 null，避免 `null` 传入 SQL 导致意外结果。
> **例外**: 可选参数、更新字段等允许 null 的场景用包装类。

```java
// 必填参数: 基本类型
UserEntity selectById(@Param("id") long id);
int deleteByUserId(@Param("userId") long userId);

// 可选参数: 包装类
List<UserEntity> selectByStatus(@Param("status") Integer status);
int updateEmail(@Param("id") long id, @Param("email") String email); // email 可选
```

### 2.4 视图 Mapper

> **适用场景**: 跨表 JOIN、聚合统计等复杂查询。
> **不适用**: 单表查询直接在标准 Mapper 中完成。

```java
@Mapper
public interface OrderViewMapper {
    OrderDetailView selectOrderDetail(@Param("orderId") long orderId);
    List<OrderDetailView> selectOrdersByUserId(@Param("userId") long userId);
}
```

视图实体是纯 POJO，不对应单张表，只映射查询结果：

```java
@Data
public class OrderDetailView {
    private Long orderId;
    private String orderNo;
    private OrderStatus status;
    private String username;      // 关联字段
    private String productName;   // 关联字段
    private BigDecimal price;     // 关联字段
}
```

---

## 三、SQL 编写

### 3.1 单表 CRUD — 复用框架方法

> **前提**: 使用 MyBatis-Plus `[MP]` 或 MyBatis-Flex `[MF]`。
> **不适用**: 原生 MyBatis 无此能力，需手写。

```java
// [MP] 使用 BaseMapper 默认方法
userMapper.selectById(id);
userMapper.insert(entity);
userMapper.updateById(entity);
userMapper.deleteById(id);

// [MF] 使用 BaseMapper 默认方法
userMapper.selectOneById(id);
userMapper.insert(entity);
userMapper.update(entity);      // Flex 的 update 需要非 null 字段
userMapper.deleteById(id);
```

不需要为简单的单表操作手写 SQL 或 XML。

### 3.2 复杂查询 — XML

> **适用**: [ALL] 多表 JOIN、动态条件、子查询、聚合等。
> **判断标准**: SQL 超过 5 行或有 `<if>`/`<choose>` 等动态标签时，放 XML。

**简单动态查询**可用注解（`@Select` + `<script>`），但不要过度使用：

```java
// 简单动态: 注解可以胜任
@Select("<script>" +
    "SELECT * FROM user WHERE 1=1" +
    "<if test='status != null'> AND status = #{status}</if>" +
    "</script>")
List<UserEntity> selectByCondition(@Param("status") Integer status);
```

**复杂查询放 XML**:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
    "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.example.mapper.OrderMapper">

    <select id="selectComplexOrders" resultType="OrderEntity">
        SELECT o.id, o.order_no, o.user_id, o.status, o.total_amount
        FROM `order` o
        WHERE o.user_id = #{userId}
        <if test="status != null">
            AND o.status = #{status}
        </if>
        <if test="startTime != null">
            AND o.created_at &gt;= #{startTime}
        </if>
        ORDER BY o.created_at DESC
    </select>

</mapper>
```

### 3.3 XML 文件位置

> 两种方式都可以，选择后在项目中保持一致。

**方式一**（推荐）: XML 与 Mapper 接口同目录

```
src/main/java/com/example/mapper/
├── OrderMapper.java
└── OrderMapper.xml
```

需要 Maven 配置包含 java 目录下的 XML：

```xml
<build>
    <resources>
        <resource>
            <directory>src/main/java</directory>
            <includes>
                <include>**/*.xml</include>
            </includes>
        </resource>
    </resources>
</build>
```

**方式二**: 放在 resources 下

```
src/main/resources/mapper/
└── OrderMapper.xml
```

---

## 四、查询方法命名

> **适用**: [ALL]

### 4.1 标准命名

| 操作 | 前缀 | 示例 |
|------|------|------|
| 查询单个 | `select` / `get` | `selectById`, `getByUsername` |
| 查询列表 | `select` / `list` | `selectList`, `listByStatus` |
| 查询数量 | `count` | `countByStatus` |
| 插入 | `insert` | `insert`, `batchInsert` |
| 更新 | `update` | `updateById`, `updateStatus` |
| 删除 | `delete` | `deleteById`, `deleteByUserId` |

项目内保持一致即可，`select` 和 `get` 不要混用。

### 4.2 条件命名

```java
selectById(long id)
selectByUsername(String username)
selectByUserIdAndStatus(long userId, OrderStatus status)
selectByCreateTimeBetween(LocalDateTime start, LocalDateTime end)
```

---

## 五、事务管理

> **适用**: [ALL] 事务是 Spring 的能力，与 MyBatis 版本无关。

### 5.1 事务注解

```java
@Transactional(rollbackFor = Exception.class)
public void createOrder(CreateOrderDTO dto) {
    orderMapper.insert(order);
    inventoryService.decreaseStock(dto.getProductId(), dto.getQuantity());
    orderDetailMapper.batchInsert(dto.getItems());
}
```

**`rollbackFor = Exception.class`**: 默认只对 `RuntimeException` 回滚，加上此参数确保 checked exception 也回滚。

> **不适用**: 只读查询不需要事务，不要给所有方法无差别加 `@Transactional`。

### 5.2 事务传播

> 大多数场景用默认 `REQUIRED` 即可。只在明确需要独立事务或不需要事务时才调整。

| 传播行为 | 适用场景 |
|---------|---------|
| `REQUIRED` (默认) | 常规业务操作，加入或新建事务 |
| `REQUIRES_NEW` | 必须独立提交的操作（如审计日志），不受外层事务回滚影响 |
| `SUPPORTS` | 读操作，有事务就加入，没有就以非事务方式执行 |
| `NOT_SUPPORTED` | 明确不需要事务的操作 |

---

## 六、分页查询

### 6.1 MyBatis-Plus 分页 `[MP]`

> **前提**: 需配置分页插件 `PaginationInnerInterceptor`。

```java
// 配置分页插件
@Configuration
public class MybatisPlusConfig {
    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));
        return interceptor;
    }
}

// 使用
public Page<UserEntity> getUsers(int pageNum, int pageSize) {
    return userMapper.selectPage(new Page<>(pageNum, pageSize), null);
}
```

### 6.2 MyBatis-Flex 分页 `[MF]`

> **前提**: Flex 内置分页支持，无需额外插件配置。

```java
// 使用
public Page<UserEntity> getUsers(int pageNum, int pageSize) {
    return userMapper.paginate(pageNum, pageSize, QueryBuilder.create());
}
```

### 6.3 原生 MyBatis 分页 `[ALL]`

> **适用**: 无增强框架时。
> **方式**: 手动拼 LIMIT，或使用 PageHelper 插件。

**PageHelper 方式**:

```java
// 引入 pagehelper 依赖后
public List<UserEntity> getUsers(int pageNum, int pageSize) {
    PageHelper.startPage(pageNum, pageSize);
    return userMapper.selectAll();  // PageHelper 自动拦截并加 LIMIT
}
```

---

## 七、批量操作

> **适用**: [ALL]

### 7.1 批量插入

**MyBatis-Plus** `[MP]`: 可直接使用 `saveBatch()`（Service 层方法）。

**通用 XML 方式**:

```xml
<insert id="batchInsert">
    INSERT INTO user (username, email, status)
    VALUES
    <foreach collection="list" item="user" separator=",">
        (#{user.username}, #{user.email}, #{user.status})
    </foreach>
</insert>
```

> **注意**: `foreach` 拼接 VALUES 在数据量大时（>1000 条）可能导致 SQL 过长。此时应在 Service 层分批提交。

### 7.2 批量更新

```xml
<update id="batchUpdate">
    <foreach collection="list" item="user" separator=";">
        UPDATE user
        SET username = #{user.username}, email = #{user.email}
        WHERE id = #{user.id}
    </foreach>
</update>
```

> **前提**: 数据库连接 URL 需添加 `allowMultiQueries=true`（MySQL），否则 `separator=";"` 的多条语句无法执行。
> **替代方案**: 不想开 `allowMultiQueries` 时，可在 Service 层循环调用单条 update，或考虑 `INSERT ... ON DUPLICATE KEY UPDATE`。

---

## 八、设计原则总结

| # | 原则 | 适用条件 |
|---|------|---------|
| 1 | 状态/类型字段用枚举 | 值域固定且有明确语义；值频繁变动时用常量类 |
| 2 | Mapper 必填参数用基本类型 | 可选参数仍用包装类 |
| 3 | 单表用框架方法，跨表用 ViewMapper + XML | `[MP]`/`[MF]` 有 BaseMapper；原生 MyBatis 需手写全部 |
| 4 | 复杂 SQL 放 XML | 5 行以上或有动态标签时 |
| 5 | 事务加 `rollbackFor = Exception.class` | 只读查询不加事务 |
| 6 | 项目内命名和风格保持一致 | 选了一种就不要混用 |
