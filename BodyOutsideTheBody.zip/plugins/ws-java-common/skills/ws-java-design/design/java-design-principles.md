# 设计原则

> 本文档定义编码修改时必须遵守的元原则。适用于所有 Java 项目。
> 约束存在的目的是保证一致性，不要为了实现方便而妥协。

---

## 一、约束守护原则

### 1.1 核心规则

当发现实现不符合约束时：

| | 做法 | 例子 |
|---|------|------|
| ✅ | 修改**实现**以满足约束 | 缺少无参构造 → 给实现类加上 |
| ❌ | 修改**约束**以适应实现 | 缺少无参构造 → 去掉无参构造要求 |

**判断标准**：约束是对所有实现者的承诺。放宽一个实现者的约束 = 打破其他实现者基于该约束做出的假设。

### 1.2 决策流程

```
发现实现不符合约束
│
├── 约束本身是否有误？（设计阶段就错了）
│   └── 是 → 重新审视设计，所有实现者一起改
│
├── 是否所有实现者都不满足？
│   └── 是 → 约束可能有误，回到上一步
│
└── 仅个别实现者不满足？
    └── 是 → 修改实现，不动约束
```

### 1.3 适用边界

- **适用**: 已经确定的设计约束（接口契约、命名规范、包结构等）
- **不适用**: 设计阶段尚未确定的决策——此时所有方案都是候选，不存在"约束"

---

## 二、反模式识别

### 2.1 危险信号关键词

当代码修改中出现以下模式时，需要警惕是否降低了设计标准：

| 关键词 | 表面理由 | 实际风险 |
|--------|---------|---------|
| "为了兼容..." | 保持向后兼容 | 可能只是在迁就一个错误的调用方 |
| "放宽条件..." | 让代码更灵活 | 约束一旦放宽，所有调用方都可能利用漏洞 |
| "可选的..." | 增加灵活性 | 如果总是可选，说明这个约束本身可能不需要 |
| "如果不满足则跳过..." | 容错处理 | 跳过的部分可能在其他地方引发更难排查的问题 |
| "添加一个例外..." | 解决特殊情况 | 例外的数量只会增加，不会减少 |
| "临时方案..." | 快速解决问题 | 临时方案往往永久存活 |

### 2.2 典型反模式

| 反模式 | 表现 | 正确做法 |
|--------|------|---------|
| 接口降级 | 为了让某个实现类"能跑"，放宽接口方法的前置/后置条件 | 修改实现类使其满足接口契约 |
| 类型绕过 | 类型检查失败时，移除检查或改为 `Object` | 修复类型使其兼容，或用泛型约束 |
| 断言弱化 | 测试失败时把精确断言改为宽松断言 | 修复代码使精确断言通过 |
| 验证跳过 | 某些数据无法通过验证时，跳过验证步骤 | 修复数据使其通过验证 |
| 注解移除 | 方法缺少必要注解时，把注解改为可选 | 为方法添加所需注解 |
| 异常吞没 | 捕获异常后不做任何处理（空 catch） | 至少记录日志，最好向上抛出或转换为业务异常 |

---

## 三、项目设计范式

> 以下范式从优秀实践中提炼，作为类设计和模块组织时的参照。不要求每个场景都套用，但偏离时需说明理由。

### 3.1 接口 → 抽象类 → 具体实现（三段式）

> **适用**: 需要多种实现且存在公共逻辑的组件（限流器、代理、校验器等）。
> **不适用**: 简单 CRUD 的 Service 层，直接接口 + 实现即可。

```
┌────────────────────┐
│     接口 (契约)      │   定义行为，面向使用者
├────────────────────┤
│   抽象类 (骨架)      │   模板方法 + 公共逻辑，面向扩展者
├────────────────────┤
│   具体实现 (血肉)    │   只实现 doXxx 钩子
└────────────────────┘
```

**约束**：

| 项目 | 规则 | 理由 |
|------|------|------|
| 接口方法 | 面向使用者的 API | 使用者只依赖接口 |
| 公共方法 | `final`，封装不变流程 | 防止子类绕过校验/前置/后置逻辑 |
| 钩子方法 | `protected abstract`，命名 `doXxx` | 子类只关注差异部分 |
| 前置校验 | 在公共方法中统一执行 | 子类不需要重复校验 |

```java
// 接口定义契约
public interface Notifier {
    void send(String target, String message);
}

// 抽象类封装骨架
public abstract class AbstractNotifier implements Notifier {

    @Override
    public final void send(String target, String message) {
        Assert.hasText(target, "target must not be empty");  // 统一校验
        doSend(target, message);                               // 委托钩子
    }

    protected abstract void doSend(String target, String message);
}

// 具体实现只关心差异
public class EmailNotifier extends AbstractNotifier {

    @Override
    protected void doSend(String target, String message) {
        // 邮件发送逻辑
    }
}
```

### 3.2 元注解包装

> **适用**: 一组注解总是同时出现，或需要为现有注解添加默认行为时。
> **不适用**: 只使用一次的注解组合，没必要封装。

通过 `@AliasFor` 委托原生注解属性，减少配置出错的可能：

```java
// 包装 @Configuration，强制 proxyBeanMethods = false
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Configuration(proxyBeanMethods = false)
public @interface ExactConfiguration {

    @AliasFor(annotation = Configuration.class)
    String value() default "";
}

// 包装 @PropertySource，注入自定义 Factory
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@PropertySource(value = "", factory = YamlPropertySourceFactory.class)
public @interface YamlSource {

    @AliasFor(annotation = PropertySource.class, attribute = "value")
    String[] value();

    @AliasFor(annotation = PropertySource.class, attribute = "ignoreResourceNotFound")
    boolean ignoreResourceNotFound() default false;
}
```

**约束**：

| 项目 | 规则 |
|------|------|
| 属性委托 | 用 `@AliasFor` 委托，不要重新定义同名属性 |
| 默认值 | 封装时设定合理的默认值，减少使用者配置负担 |
| 文档 | 说明封装了哪些原生注解，以及增加了什么默认行为 |

### 3.3 异常上下文绑定

> **适用**: 模块有统一异常体系，且异常来源可以从上下文推导时。
> **不适用**: 异常信息简单到不需要额外上下文时（如 `IllegalArgumentException`）。

异常基类在构造函数中自动组合来源信息，子类无需关心格式化：

```java
// 抽象基类 — 构造函数组合上下文消息
public abstract class ModuleException extends RuntimeException {

    protected ModuleException(String context, String message) {
        super(formatMessage(context, message));
    }

    protected ModuleException(String context, String message, Throwable cause) {
        super(formatMessage(context, message), cause);
    }

    private static String formatMessage(String context, String message) {
        return String.format("[%s]: %s", context, message);
    }
}

// 具体子类 — 无需关心消息格式化
public class ConnectionException extends ModuleException {

    public ConnectionException(String host, String message) {
        super(host, message);  // 自动格式化为 [host]: message
    }
}
```

**约束**：

| 项目 | 规则 | 理由 |
|------|------|------|
| 基类构造函数 | 包级可见（不加 `public`） | 防止外部代码直接 `new` 基类异常 |
| 消息格式化 | 集中在基类，不在子类拼接 | 保证格式一致性 |
| 标准构造函数 | 提供 4 个标准签名（无参/message/cause/message+cause） | 符合 Java 异常惯例，按需裁剪 |

### 3.4 不可变性保护

> **适用**: 构建完成后不应被修改的集合（缓存、查找表、配置映射等）。
> **不适用**: 需要频繁增删的临时集合。

```java
// 构建时收集 → 构建完成后包装为不可变
Map<Object, Enum> tmp = new LinkedHashMap<>();
for (Enum e : enumClass.getEnumConstants()) {
    Object value = getValue(e);
    Assert.notNull(value, "enum value must not be null");
    Assert.isTrue(!tmp.containsKey(value),
        () -> String.format("duplicate value [%s] in enum [%s]", value, enumClass.getName()));
    tmp.put(value, e);
}
return Collections.unmodifiableMap(tmp);  // 对外不可变
```

**原则**：内部可变（构建阶段），外部不可变（返回后）。构建过程中做好重复性校验。

### 3.5 懒加载缓存

> **适用**: 构建成本较高但不一定每次都会用到的查找结构。
> **不适用**: 构建成本很低或必定会用到的结构，直接初始化。

```java
private static final Map<Class<?>, Map<Object, Enum>> CACHE = new ConcurrentHashMap<>();

public static Map<Object, Enum> getValueMap(Class<? extends Enum> enumClass) {
    return CACHE.computeIfAbsent(enumClass, clazz -> {
        // 构建逻辑（可能抛出异常，computeIfAbsent 保证原子性）
        return buildMap(clazz);
    });
}
```

**约束**：

| 项目 | 规则 | 理由 |
|------|------|------|
| 缓存容器 | `ConcurrentHashMap` | 线程安全，`computeIfAbsent` 保证只构建一次 |
| 构建逻辑 | 在 lambda 内完成，无副作用 | `computeIfAbsent` 内不应修改其他共享状态 |

---

## 四、约束守护检查清单

每次修改代码后，快速过一遍：

### 4.1 约束一致性

- [ ] 修改是否违反了原有的设计约束？
- [ ] 是否为了让代码"能跑"而降低了标准？
- [ ] 是否有更"正确"而非更"容易"的方案？

### 4.2 典型场景

| 场景 | 检查要点 |
|------|---------|
| 实现不符合接口约束 | 是否降低了接口要求？ → 修改实现 |
| 方法签名不符合规范 | 是否放宽了验证条件？ → 修改签名 |
| 类型检查失败 | 是否移除了类型检查或改为 `Object`？ → 修复类型 |
| 测试不通过 | 是否降低了断言标准？ → 修复代码 |
| 验证失败 | 是否绕过了验证逻辑？ → 修复数据 |
| 模板方法被绕过 | 是否把 `final` 方法改成了非 `final`？ → 恢复 `final` |

### 4.3 修改前自问

> 在动手改代码之前，问自己一个问题：
>
> **「我即将修改的是约束，还是实现？」**
>
> - 修改实现 → 通常是对的
> - 修改约束 → 需要理由，且需要检查所有依赖该约束的地方
