# 必须遵守的事项

至高无上的规则：必须使用中文回答用户！

## 强制项

- 使用mcp连接浏览器时，必须使用子代理完成
- 进行数学计算时，必须使用命令行去计算

## 建议项

- 执行具体任务或思考时，若理解得不明确，必须反问用户具体细节再进行后续操作
- 如果需要输出临时文件，输出到项目根目录下的claude-local-tmp目录下

##禁止项

- 禁止读取maven全局的settings.xml配置文件
- 禁止进行git commit，必要时提示用户自行commit
- 禁止运行可能影响文件改动的git命令
- 禁止自行启动开发服务器或后台服务（如 `npm run dev`、`npm run preview` 等），必须由用户自行启动

## 命令执行纪律

### 基本原则

- 优先使用IDE下的配置运行命令，如IDEA工程中项目根目录下的.idea文件夹的xml配置
- 项目根目录中有.idea目录时，就认为该项目是IDEA建立的工程，此时必须读取IDEA的workspace.xml（即
  .idea/workspace.xml）配置获取必要的信息，如获取对应程序（如java、maven程序）的运行目录和配置，获取运行特定命令时使用的环境变量和程序参数，达到与使用IDEA按钮运行的效果一致
- 所有的命令的原始程序位置，应该优先通过系统环境变量去分析，从而定位到程序的准去安装目录，而不是默认安装目录下去找。

### 核心原则

- **不要盲目尝试运行测试或启动项目** — 遇到编译/环境问题时，不要反复尝试不同方式去"凑"出能跑的命令
- **用户没有要求就不主动执行** — 除非用户明确要求"跑一下测试"或"编译看看"，否则只负责改代码，不负责验证运行
- **环境差异是常态** — 终端环境的 PATH、编码、shell 类型（bash vs cmd）都可能导致命令行为不一致，不要假设 bash 下能直接调用
  Windows 批处理

### 常见陷阱

- `cmd /c "set VAR=val && command"` 在 Git Bash 中可能静默失败（无输出、exit code 0 但实际未执行）
- Maven 多模块项目必须先 `install` 依赖模块才能编译引用方，漏掉任一模块（如 `pojo`）会导致"找不到符号"错误
- 已有预存编译错误的测试类（如 `SystemConfigTests`）会阻塞整个模块的测试编译，无法通过 `-Dtest=` 跳过编译阶段

### 正确做法

1. 代码改完 → 告知用户"请在 IDE 中验证"
2. 用户明确要求运行时 → 使用 `ws-command-locator` skill 确认正确的程序路径
3. 运行失败 → 报告错误信息，分析原因，**不要连续重试超过 2 次**

### java命令

使用java命令时，需要使用对应项目所用版本的java程序，不能用来自系统环境变量的java程序

### mvn命令（maven）

- 如果项目为IDEA工程的话（存在.idea目录），必须优先使用IDEA工程指定的maven程序和版本，如果项目为IDEA工程的话（存在.idea目录）
- 使用mvn命令时，必须通过-D参数指定java home目录，根据所属项目选择合适的java home（见上）

<!-- CODEGRAPH_START -->

## CodeGraph

This project has a CodeGraph MCP server (`codegraph_*` tools) configured. CodeGraph is a tree-sitter-parsed knowledge
graph of every symbol, edge, and file. Reads are sub-millisecond and return structural information grep cannot.

### 🚫 Mandatory rules — do NOT skip

These are **rules**, not suggestions. Models that haven't been
fine-tuned on codegraph (DeepSeek, Qwen, GLM, HunYuan, …) often fall back to
grep/Read by training-data habit even when codegraph is faster.

1. **NEVER grep / find / Read to look up a symbol by name.** Use `codegraph_search` or `codegraph_context` first.
2. **NEVER chain Read + grep to trace how something works.** Use `codegraph_context` (one call) plus ONE
   `codegraph_explore`.
3. **NEVER call `codegraph_node` more than 3 times in a row.** Switch to `codegraph_explore` which batches by file in a
   single capped call.
4. **NEVER trust an edge tagged `[heur 0.NN ⚠️]` (confidence < 0.7) without verifying.** Open the call site to confirm
   before relying on the relationship.
5. **NEVER answer when the response footer shows `⚠️ Index age:` over 30 minutes.** Ask the user to run
   `codegraph sync`, or check `codegraph_status`.

### When to prefer codegraph over native search

Use codegraph for **structural** questions — what calls what, what would break, where is X defined, what is X's
signature. Use native grep/read only for **literal text** queries (string contents, comments, log messages) or after you
already have a specific file open.

| Question | Tool |
|---|---|
| "Where is X defined?" / "Find symbol named X" | `codegraph_search` |
| "What calls function Y?" | `codegraph_callers` |
| "What does Y call?" | `codegraph_callees` |
| "What would break if I changed Z?" | `codegraph_impact` |
| "Show me Y's signature / source / docstring" | `codegraph_node` |
| "Give me focused context for a task/area" | `codegraph_context` |
| "See several related symbols' source at once" | `codegraph_explore` |
| "What files exist under path/" | `codegraph_files` |
| "Is the index healthy?" | `codegraph_status` |

### Rules of thumb

- **Answer directly — don't delegate exploration.** For "how does X work" / architecture / trace questions, answer with
  2-3 codegraph calls: `codegraph_context` first, then ONE `codegraph_explore` for the source of the symbols it
  surfaces. Codegraph IS the pre-built index, so spawning a separate file-reading sub-task/agent — or running a grep +
  read loop — repeats work codegraph already did and costs more for the same answer.
- **Trust codegraph results.** They come from a full AST parse. Do NOT re-verify them with grep — that's slower, less
  accurate, and wastes context.
- **Don't grep first** when looking up a symbol by name. `codegraph_search` is faster and returns kind + location +
  signature in one call.
- **Don't chain `codegraph_search` + `codegraph_node`** when you just want context — `codegraph_context` is one call.
- **Don't loop `codegraph_node` over many symbols** — one `codegraph_explore` call returns several symbols' source
  grouped in a single capped call, while each separate node/Read call re-reads the whole context and costs far more.
- **Index lag**: the file watcher debounces ~500ms behind writes; don't re-query immediately after editing a file in the
  same turn.

### If `.codegraph/` doesn't exist

The MCP server returns "not initialized." Ask the user: *"I notice this project doesn't have CodeGraph initialized. Want
me to run `codegraph init -i` to build the index?"*

---

## CodeGraph（中文）

本项目已配置 CodeGraph MCP 服务（`codegraph_*` 工具集）。CodeGraph 基于
tree-sitter 解析了项目中每一个符号、关系和文件，读取耗时亚毫秒级，能够返回
grep 无法提供的结构化信息。

### 🚫 强制规则 —— 必须遵守

以下是**强制规则**，不是建议。未经 codegraph 微调的模型（DeepSeek、Qwen、
GLM、HunYuan 等）常因训练习惯而退回 grep / Read，即使 codegraph 更快。请严格遵守：

1. **绝不**用 grep / find / Read 按名查找符号。优先调用 `codegraph_search` 或 `codegraph_context`。
2. **绝不**用 Read + grep 串联来追踪 X 是怎么工作的。一次 `codegraph_context` 加一次 `codegraph_explore` 即可。
3. **绝不**连续调用 `codegraph_node` 超过 3 次。切换到 `codegraph_explore` —— 它一次按文件聚合返回全部源码。
4. **绝不**信任置信度 < 0.7 的关系边（被标 `[heur 0.NN ⚠️]`）。先用 `codegraph_node` 或 Read 该行确认调用关系，再做出依赖性判断。
5. **绝不**在响应底部出现 `⚠️ Index age:` 且超过 30 分钟时直接回答。先让用户执行 `codegraph sync`，或用 `codegraph_status`
   确认 watcher 状态。

### 何时优先用 codegraph 而非原生搜索

涉及**结构性**问题（谁调用谁、改了会破坏什么、X 在哪定义、X 的签名是什么）
请用 codegraph；只在查询**字面文本**（字符串内容、注释、日志消息）或已经
打开了具体文件时，才使用原生 grep/read。

| 问题 | 工具 |
|---|---|
| "X 在哪定义？" / "找名字叫 X 的符号" | `codegraph_search` |
| "谁调用了函数 Y？" | `codegraph_callers` |
| "Y 调用了哪些东西？" | `codegraph_callees` |
| "改 Z 会影响哪些地方？" | `codegraph_impact` |
| "看 Y 的签名 / 源码 / docstring" | `codegraph_node` |
| "针对某个任务/区域给我聚焦的上下文" | `codegraph_context` |
| "一次性看几个相关符号的源码" | `codegraph_explore` |
| "path/ 下有哪些文件" | `codegraph_files` |
| "索引是否健康？" | `codegraph_status` |

### 经验法则

- **直接回答 —— 不要把探索委派给子任务/子代理**。对"X 是怎么工作的"/架构/追踪类问题，用 2-3 次 codegraph 调用即可：先
  `codegraph_context`，再一次 `codegraph_explore` 拿涉及符号的源码。codegraph 本身就是预建好的索引，再去派生一个文件读取的子代理、或自己跑
  grep + read 循环，是在重复 codegraph 已经做完的工作，且成本更高。
- **信任 codegraph 的结果**。它们来自完整的 AST 解析；不要再用 grep 二次验证 —— 那样更慢、不准、还浪费上下文。
- **按名查找符号时不要先 grep**：`codegraph_search` 一次返回种类、位置、签名。
- **不要串 `codegraph_search` + `codegraph_node`**：想要上下文就直接用 `codegraph_context`（一次调用搞定）。
- **不要对一堆符号循环调用 `codegraph_node`**：一次 `codegraph_explore` 就按文件聚合返回它们的源码；逐个 node/Read
  会反复读取整段上下文，成本高得多。
- **索引延迟**：文件 watcher 会去抖约 500ms；编辑文件后不要在同一轮立刻再查询。

### 如果 `.codegraph/` 不存在

MCP 服务会返回 "not initialized."。请询问用户："*我注意到这个项目还没有初始化 CodeGraph，要我运行 `codegraph init -i`
来构建索引吗？*"
<!-- CODEGRAPH_END -->
